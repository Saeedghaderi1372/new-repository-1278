cmake_minimum_required(VERSION 3.22.1)
project("gigacam_native")

add_library(
    gigacam_native
    SHARED
    gigacam_native.cpp
)

find_library(log-lib log)
find_library(jnigraphics-lib jnigraphics)

target_link_libraries(
    gigacam_native
    ${log-lib}
    ${jnigraphics-lib}
)
