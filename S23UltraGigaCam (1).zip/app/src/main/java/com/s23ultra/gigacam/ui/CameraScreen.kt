package com.s23ultra.gigacam.ui

import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.s23ultra.gigacam.domain.*
import kotlin.math.abs
import kotlin.math.max

@Composable
fun CameraScreen(
    viewModel: CameraViewModel,
    onOpenGigaViewer: () -> Unit
) {
    val settings by viewModel.settings.collectAsState()
    val telemetry by viewModel.telemetry.collectAsState()
    val progress by viewModel.captureProgress.collectAsState()
    val matrixState by viewModel.matrixState.collectAsState()

    var showAiSheet by remember { mutableStateOf(false) }
    var activeProDial by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // 1) Live Camera2 Preview SurfaceView
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                SurfaceView(ctx).apply {
                    holder.addCallback(object : SurfaceHolder.Callback {
                        override fun surfaceCreated(holder: SurfaceHolder) {
                            viewModel.attachPreviewSurface(holder.surface)
                        }

                        override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, ht: Int) = Unit

                        override fun surfaceDestroyed(holder: SurfaceHolder) {
                            viewModel.detachPreviewSurface()
                        }
                    })
                }
            }
        )

        // 2) Viewfinder Overlays (Composition Grid + 3D Horizon Leveler + Guided Gigapixel Matrix)
        ViewfinderOverlays(
            settings = settings,
            telemetry = telemetry,
            matrixState = matrixState
        )

        // 3) Top Bar: Resolution Selector (200 / 300 / 500 / 800 / 1000 / 2000 / 5000 MP) + AI + Telemetry
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .background(Color(0x99000000))
                .padding(vertical = 8.dp)
                .align(Alignment.TopCenter)
        ) {
            // Top Status & Quick Toggles
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // AI Mode Badge Button
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (settings.aiConfig.enabled) Color(0xFF0284C7) else Color(0xFF1F2937))
                        .clickable { showAiSheet = true }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (settings.aiConfig.enabled) "AI: ${settings.aiConfig.preset.labelFa}" else "AI خاموش",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // RAW DNG Toggle + Histogram Toggle + Storage & Temp Telemetry
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    ToggleChip("RAW", settings.captureRawDng) {
                        viewModel.updateSettings { it.copy(captureRawDng = !it.captureRawDng) }
                    }
                    ToggleChip("HIST", settings.showHistogram) {
                        viewModel.updateSettings { it.copy(showHistogram = !it.showHistogram) }
                    }
                    ToggleChip("GRID", settings.gridOverlay != GridOverlayType.NONE) {
                        viewModel.updateSettings {
                            val next = if (it.gridOverlay == GridOverlayType.NONE) GridOverlayType.RULE_OF_THIRDS
                            else if (it.gridOverlay == GridOverlayType.RULE_OF_THIRDS) GridOverlayType.GOLDEN_RATIO
                            else GridOverlayType.NONE
                            it.copy(gridOverlay = next)
                        }
                    }
                    Text(
                        text = "%.1fGB • %.0f°C".format(telemetry.freeStorageGb, telemetry.batteryTempC),
                        color = if (telemetry.batteryTempC > 43f) Color(0xFFEF4444) else Color(0xFFCBD5E1),
                        fontSize = 10.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Ultra-MP Resolution Selector Bar (200 .. 5000 MP)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ResolutionPreset.entries.forEach { preset ->
                    val selected = settings.resolutionPreset == preset
                    val isGigapixel = preset.megapixels >= 1000
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                when {
                                    selected && isGigapixel -> Color(0xFFF59E0B)
                                    selected -> Color(0xFF38BDF8)
                                    else -> Color(0xAA111827)
                                }
                            )
                            .border(
                                width = 1.dp,
                                color = if (selected) Color.White else Color(0xFF374151),
                                shape = RoundedCornerShape(16.dp)
                            )
                            .clickable { viewModel.selectResolutionPreset(preset) }
                            .padding(horizontal = 11.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = preset.label,
                            color = if (selected) Color.Black else Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }

            // Active Preset Strategy Info Strip
            val p = settings.resolutionPreset
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${p.targetWidth}×${p.targetHeight} • ${p.descriptionFa}",
                    color = Color(0xFFFDE68A),
                    fontSize = 10.sp,
                    maxLines = 1
                )
            }
        }

        // 4) Live RGB/Luma Histogram + Focus Peaking Sharpness HUD (Top-Right below header)
        if (settings.showHistogram) {
            LiveHistogramWidget(
                histogram = telemetry.histogramLuma,
                zebraRatio = telemetry.zebraClipRatio,
                sharpnessScore = telemetry.focusSharpnessScore,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 132.dp, end = 12.dp)
            )
        }

        // 5) Guided Gigapixel Matrix Banner (if active for 800–5000 MP)
        if (matrixState.active) {
            Column(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 132.dp)
                    .background(Color(0xDD0F172A), RoundedCornerShape(14.dp))
                    .border(1.dp, Color(0xFFF59E0B), RoundedCornerShape(14.dp))
                    .padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "کاشی ${matrixState.currentIndex + 1} از ${matrixState.targets.size} — دایره را روی هدف زرد نگه دارید",
                    color = Color(0xFFF59E0B),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Button(
                    onClick = { viewModel.cancelGuidedMatrix() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)
                ) {
                    Text("لغو ماتریس", fontSize = 11.sp, color = Color.White)
                }
            }
        }

        // 6) Processing Progress Overlay
        if (progress.isCapturing) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .width(290.dp)
                    .background(Color(0xEE0B1120), RoundedCornerShape(18.dp))
                    .border(1.dp, Color(0xFF38BDF8), RoundedCornerShape(18.dp))
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = progress.stageTitleFa,
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { progress.progressFraction },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                    color = Color(0xFFF59E0B),
                    trackColor = Color(0xFF1E293B)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text("${(progress.progressFraction * 100).toInt()}%", color = Color(0xFF38BDF8), fontSize = 12.sp)
            }
        }

        // 7) Error Toast Banner
        progress.errorMessage?.let { err ->
            Row(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(horizontal = 24.dp)
                    .background(Color(0xEE7F1D1D), RoundedCornerShape(12.dp))
                    .clickable { viewModel.clearError() }
                    .padding(14.dp)
            ) {
                Text(err, color = Color.White, fontSize = 12.sp)
            }
        }

        // 8) Bottom Control Deck (Pro Dials + 4-Lens Selector + Mode Switcher + Shutter)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Color(0xCC05070A))
                .navigationBarsPadding()
                .padding(top = 8.dp, bottom = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Active Pro Parameter Slider
            activeProDial?.let { dial ->
                ProParameterSlider(
                    dialKey = dial,
                    settings = settings,
                    onUpdate = viewModel::updateSettings
                )
            }

            // Pro Manual Parameters Row (ISO | SHUTTER | EV | MF | WB)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                ProDialPill("ISO", if (settings.manualExposure) "${settings.iso}" else "AUTO", activeProDial == "ISO") {
                    activeProDial = if (activeProDial == "ISO") null else "ISO"
                }
                val shutterLabel = if (settings.manualExposure) formatShutter(settings.shutterSpeedNs) else "AUTO"
                ProDialPill("SPEED", shutterLabel, activeProDial == "SPEED") {
                    activeProDial = if (activeProDial == "SPEED") null else "SPEED"
                }
                ProDialPill("EV", "%+d".format(settings.evCompensation), activeProDial == "EV") {
                    activeProDial = if (activeProDial == "EV") null else "EV"
                }
                ProDialPill("FOCUS", if (settings.manualFocus) "%.1fD".format(settings.focusDistanceDiopters) else "AF", activeProDial == "FOCUS") {
                    activeProDial = if (activeProDial == "FOCUS") null else "FOCUS"
                }
                ProDialPill("WB", if (settings.manualWhiteBalance) "${settings.whiteBalanceKelvin}K" else "AWB", activeProDial == "WB") {
                    activeProDial = if (activeProDial == "WB") null else "WB"
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Samsung S23 Ultra 4-Lens Optical Switcher (0.6x | 1x | 3x | 10x)
            Row(
                modifier = Modifier
                    .background(Color(0xAA111827), RoundedCornerShape(24.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                S23UltraLens.entries.forEach { lens ->
                    val selected = settings.selectedLens == lens
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(if (selected) Color(0xFFF59E0B) else Color.Transparent)
                            .clickable { viewModel.selectLens(lens) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = lens.zoomLabel,
                            color = if (selected) Color.Black else Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Shooting Modes Strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                ShootingMode.entries.forEach { mode ->
                    val selected = settings.shootingMode == mode
                    Text(
                        text = mode.labelFa,
                        color = if (selected) Color(0xFFF59E0B) else Color(0xFF9CA3AF),
                        fontSize = 12.sp,
                        fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium,
                        modifier = Modifier.clickable { viewModel.selectShootingMode(mode) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main Shutter Row: GigaViewer Thumbnail | Shutter Button | AI Studio Button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 32.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Open Gigapixel Deep-Zoom Viewer
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF1E293B))
                        .border(1.5.dp, Color(0xFF38BDF8), RoundedCornerShape(12.dp))
                        .clickable { onOpenGigaViewer() },
                    contentAlignment = Alignment.Center
                ) {
                    Text("GIGA\nVIEW", color = Color(0xFF38BDF8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                // Pro Shutter Trigger
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .border(4.dp, Color.White, CircleShape)
                        .padding(6.dp)
                        .clip(CircleShape)
                        .background(
                            if (settings.resolutionPreset.megapixels >= 1000) Color(0xFFF59E0B)
                            else Color.White
                        )
                        .clickable(enabled = !progress.isCapturing) { viewModel.onShutterPressed() },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = settings.resolutionPreset.label.replace(" ", "\n"),
                        color = Color.Black,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                // AI Ultra Control Sheet Button
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(if (settings.aiConfig.enabled) Color(0xFF0284C7) else Color(0xFF1E293B))
                        .border(1.5.dp, Color(0xFF38BDF8), CircleShape)
                        .clickable { showAiSheet = true },
                    contentAlignment = Alignment.Center
                ) {
                    Text("AI\nPRO", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showAiSheet) {
        AiSettingsSheet(
            aiConfig = settings.aiConfig,
            isOnnxModelLoaded = viewModel.isNeuralOnnxLoaded,
            onUpdate = viewModel::updateAiConfig,
            onDismiss = { showAiSheet = false }
        )
    }
}

@Composable
private fun ViewfinderOverlays(
    settings: ProCameraSettings,
    telemetry: LiveTelemetry,
    matrixState: GuidedMatrixState
) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        // Composition Grid
        if (settings.gridOverlay == GridOverlayType.RULE_OF_THIRDS) {
            val col = Color(0x55FFFFFF)
            drawLine(col, Offset(size.width / 3f, 0f), Offset(size.width / 3f, size.height), 1.5f)
            drawLine(col, Offset(2f * size.width / 3f, 0f), Offset(2f * size.width / 3f, size.height), 1.5f)
            drawLine(col, Offset(0f, size.height / 3f), Offset(size.width, size.height / 3f), 1.5f)
            drawLine(col, Offset(0f, 2f * size.height / 3f), Offset(size.width, 2f * size.height / 3f), 1.5f)
        } else if (settings.gridOverlay == GridOverlayType.GOLDEN_RATIO) {
            val col = Color(0x66F59E0B)
            val phi1 = 0.382f
            val phi2 = 0.618f
            drawLine(col, Offset(size.width * phi1, 0f), Offset(size.width * phi1, size.height), 1.5f)
            drawLine(col, Offset(size.width * phi2, 0f), Offset(size.width * phi2, size.height), 1.5f)
            drawLine(col, Offset(0f, size.height * phi1), Offset(size.width, size.height * phi1), 1.5f)
            drawLine(col, Offset(0f, size.height * phi2), Offset(size.width, size.height * phi2), 1.5f)
        }

        // Electronic Horizon Spirit Leveler
        if (settings.showLeveler) {
            val isLevel = abs(telemetry.rollDeg) < 1.2f
            val levelColor = if (isLevel) Color(0xFF22C55E) else Color(0xAAFFFFFF)
            val cx = size.width / 2f
            val cy = size.height / 2f
            val rad = Math.toRadians(telemetry.rollDeg.toDouble())
            val halfLen = 70f
            val dx = (kotlin.math.cos(rad) * halfLen).toFloat()
            val dy = (kotlin.math.sin(rad) * halfLen).toFloat()
            drawLine(levelColor, Offset(cx - dx, cy - dy), Offset(cx + dx, cy + dy), strokeWidth = 3f)
        }

        // Guided Gigapixel Matrix AR Target Overlay
        if (matrixState.active && matrixState.currentIndex < matrixState.targets.size) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val pxPerDeg = 18f

            // Fixed center camera reticle
            drawCircle(
                color = if (matrixState.isAlignedAndSteady) Color(0xFF22C55E) else Color.White,
                radius = 34f,
                center = Offset(cx, cy),
                style = Stroke(width = 4f)
            )

            // Draw all grid targets in angular space relative to current aim
            matrixState.targets.forEachIndexed { idx, target ->
                val dx = (target.targetYawDeg - matrixState.relYawDeg) * pxPerDeg
                val dy = (matrixState.relPitchDeg - target.targetPitchDeg) * pxPerDeg
                val pt = Offset(cx + dx, cy + dy)
                val color = when {
                    target.captured -> Color(0xAA22C55E)
                    idx == matrixState.currentIndex -> Color(0xFFF59E0B)
                    else -> Color(0x6638BDF8)
                }
                drawCircle(
                    color = color,
                    radius = if (idx == matrixState.currentIndex) 20f else 10f,
                    center = pt
                )
            }
        }
    }
}

@Composable
private fun LiveHistogramWidget(
    histogram: IntArray,
    zebraRatio: Float,
    sharpnessScore: Float,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .width(128.dp)
            .background(Color(0x99000000), RoundedCornerShape(8.dp))
            .border(1.dp, Color(0x44FFFFFF), RoundedCornerShape(8.dp))
            .padding(6.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxWidth().height(42.dp)) {
            val maxVal = max(1, histogram.maxOrNull() ?: 1).toFloat()
            val path = Path().apply { moveTo(0f, size.height) }
            val step = 4
            for (i in 0 until 256 step step) {
                val x = (i / 255f) * size.width
                val y = size.height - ((histogram[i] / maxVal) * size.height)
                path.lineTo(x, y)
            }
            path.lineTo(size.width, size.height)
            path.close()
            drawPath(path, color = Color(0xCC38BDF8))
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("FP:${sharpnessScore.toInt()}", color = Color(0xFF34D399), fontSize = 9.sp)
            Text(
                "CLIP:${(zebraRatio * 100).toInt()}%",
                color = if (zebraRatio > 0.05f) Color(0xFFEF4444) else Color(0xFF94A3B8),
                fontSize = 9.sp
            )
        }
    }
}

@Composable
private fun ProParameterSlider(
    dialKey: String,
    settings: ProCameraSettings,
    onUpdate: ((ProCameraSettings) -> ProCameraSettings) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 4.dp)
            .background(Color(0xDD111827), RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        when (dialKey) {
            "ISO" -> {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("ISO حساسیت سنسور: ${settings.iso}", color = Color.White, fontSize = 12.sp)
                    Text(
                        "AUTO",
                        color = Color(0xFFF59E0B),
                        fontSize = 11.sp,
                        modifier = Modifier.clickable { onUpdate { it.copy(manualExposure = false) } }
                    )
                }
                Slider(
                    value = settings.iso.toFloat(),
                    onValueChange = { v -> onUpdate { it.copy(manualExposure = true, iso = v.toInt()) } },
                    valueRange = 50f..3200f
                )
            }
            "SPEED" -> {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("سرعت شاتر: ${formatShutter(settings.shutterSpeedNs)}", color = Color.White, fontSize = 12.sp)
                    Text(
                        "AUTO",
                        color = Color(0xFFF59E0B),
                        fontSize = 11.sp,
                        modifier = Modifier.clickable { onUpdate { it.copy(manualExposure = false) } }
                    )
                }
                // Logarithmic scale from 1/8000s to 15s
                val expLog = kotlin.math.ln(settings.shutterSpeedNs.coerceAtLeast(125_000L).toDouble()).toFloat()
                Slider(
                    value = expLog,
                    onValueChange = { v ->
                        val ns = kotlin.math.exp(v.toDouble()).toLong().coerceIn(125_000L, 15_000_000_000L)
                        onUpdate { it.copy(manualExposure = true, shutterSpeedNs = ns) }
                    },
                    valueRange = 11.73f..23.43f
                )
            }
            "EV" -> {
                Text("جبران نوردهی (EV): %+d".format(settings.evCompensation), color = Color.White, fontSize = 12.sp)
                Slider(
                    value = settings.evCompensation.toFloat(),
                    onValueChange = { v -> onUpdate { it.copy(manualExposure = false, evCompensation = v.toInt()) } },
                    valueRange = -12f..12f
                )
            }
            "FOCUS" -> {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("فوکوس دستی: %.2f دیوپتر".format(settings.focusDistanceDiopters), color = Color.White, fontSize = 12.sp)
                    Text(
                        "AF خودکار",
                        color = Color(0xFFF59E0B),
                        fontSize = 11.sp,
                        modifier = Modifier.clickable { onUpdate { it.copy(manualFocus = false) } }
                    )
                }
                Slider(
                    value = settings.focusDistanceDiopters,
                    onValueChange = { v -> onUpdate { it.copy(manualFocus = true, focusDistanceDiopters = v) } },
                    valueRange = 0f..10f
                )
            }
            "WB" -> {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("تراز سفیدی: ${settings.whiteBalanceKelvin}K", color = Color.White, fontSize = 12.sp)
                    Text(
                        "AWB",
                        color = Color(0xFFF59E0B),
                        fontSize = 11.sp,
                        modifier = Modifier.clickable { onUpdate { it.copy(manualWhiteBalance = false) } }
                    )
                }
                Slider(
                    value = settings.whiteBalanceKelvin.toFloat(),
                    onValueChange = { v -> onUpdate { it.copy(manualWhiteBalance = true, whiteBalanceKelvin = v.toInt()) } },
                    valueRange = 2300f..10000f
                )
            }
        }
    }
}

@Composable
private fun ProDialPill(label: String, value: String, active: Boolean, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (active) Color(0xFF1E293B) else Color.Transparent)
            .border(1.dp, if (active) Color(0xFFF59E0B) else Color(0x33FFFFFF), RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, color = Color(0xFF94A3B8), fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(value, color = if (active) Color(0xFFF59E0B) else Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ToggleChip(label: String, active: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (active) Color(0xFFF59E0B) else Color(0x881F2937))
            .clickable(onClick = onClick)
            .padding(horizontal = 7.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            color = if (active) Color.Black else Color.White,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

private fun formatShutter(ns: Long): String {
    val sec = ns / 1_000_000_000.0
    return if (sec >= 0.5) "%.1fs".format(sec)
    else "1/${(1.0 / sec).toInt()}"
}
