package com.s23ultra.gigacam.processing

import java.io.Closeable
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Genuine 64-bit BigTIFF (TIFF version 43) streaming strip writer.
 *
 * Why BigTIFF is mandatory for 1000MP, 2000MP, and 5000MP photos:
 * - Standard JPEG has a hard specification ceiling of 65,535 x 65,535 pixels.
 * - Standard 32-bit TIFF is capped at 4 GB file size (5000 MP RGB uncompressed is ~15 GB).
 * - BigTIFF uses 64-bit offsets (version = 43, offset byte size = 8), allowing images far beyond
 *   5 Gigapixels to be streamed strip-by-strip directly to UFS 4.0 storage on Galaxy S23 Ultra
 *   while keeping peak RAM usage under ~128 MB!
 */
class TiledBigTiffWriter(
    outputFile: File,
    private val width: Int,
    private val height: Int,
    private val rowsPerStrip: Int = 256
) : Closeable {

    private val raf = RandomAccessFile(outputFile, "rw")
    private val stripOffsets = mutableListOf<Long>()
    private val stripByteCounts = mutableListOf<Long>()
    private var rowsWritten = 0

    init {
        raf.setLength(0L)
        // Write 16-byte BigTIFF header (Little-Endian "II", Version 43, OffsetSize 8, Reserved 0, IFD Offset placeholder)
        val header = ByteBuffer.allocate(16).order(ByteOrder.LITTLE_ENDIAN).apply {
            put('I'.code.toByte())
            put('I'.code.toByte())
            putShort(43.toShort())   // BigTIFF magic version
            putShort(8.toShort())    // 8-byte (64-bit) offsets
            putShort(0.toShort())    // Reserved constant
            putLong(0L)              // Placeholder for 64-bit first IFD offset (patched on close)
        }
        raf.write(header.array())
    }

    /**
     * Streams one strip of packed 24-bit RGB scanlines directly to disk.
     */
    fun writeRgbStrip(rgbBytes: ByteArray, stripRowCount: Int) {
        val expected = width.toLong() * stripRowCount.toLong() * 3L
        require(rgbBytes.size.toLong() == expected) {
            "Strip size mismatch: got ${rgbBytes.size}, expected $expected"
        }
        val offset = raf.filePointer
        raf.write(rgbBytes)
        stripOffsets.add(offset)
        stripByteCounts.add(rgbBytes.size.toLong())
        rowsWritten += stripRowCount
    }

    override fun close() {
        try {
            if (stripOffsets.isNotEmpty()) {
                writeBigTiffIfd()
            }
        } finally {
            raf.close()
        }
    }

    private fun writeBigTiffIfd() {
        // Align to 8-byte boundary
        while (raf.filePointer % 8L != 0L) raf.write(0)

        // Write auxiliary arrays first: BitsPerSample (3 shorts), StripOffsets (N LONG8), StripByteCounts (N LONG8)
        val bpsOffset = raf.filePointer
        val bpsBuf = ByteBuffer.allocate(6).order(ByteOrder.LITTLE_ENDIAN)
            .putShort(8).putShort(8).putShort(8)
        raf.write(bpsBuf.array())

        while (raf.filePointer % 8L != 0L) raf.write(0)
        val offsetsArrayPos = raf.filePointer
        val offsetsBuf = ByteBuffer.allocate(stripOffsets.size * 8).order(ByteOrder.LITTLE_ENDIAN)
        stripOffsets.forEach { offsetsBuf.putLong(it) }
        raf.write(offsetsBuf.array())

        val countsArrayPos = raf.filePointer
        val countsBuf = ByteBuffer.allocate(stripByteCounts.size * 8).order(ByteOrder.LITTLE_ENDIAN)
        stripByteCounts.forEach { countsBuf.putLong(it) }
        raf.write(countsBuf.array())

        val softwareTag = "S23 Ultra GigaCam BigTIFF Engine\u0000".toByteArray(Charsets.US_ASCII)
        val softwarePos = raf.filePointer
        raf.write(softwareTag)

        while (raf.filePointer % 8L != 0L) raf.write(0)
        val ifdOffset = raf.filePointer

        // BigTIFF IFD: 8-byte entry count + 20 bytes per entry + 8-byte next IFD (0)
        // Tags must be in strictly ascending numerical order per TIFF spec
        val entryCount = 10L
        val ifdBuf = ByteBuffer.allocate(8 + (entryCount.toInt() * 20) + 8).order(ByteOrder.LITTLE_ENDIAN)
        ifdBuf.putLong(entryCount)

        // Helper for 20-byte BigTIFF directory entry: tag(2), type(2), count(8), valueOrOffset(8)
        fun putEntry(tag: Int, type: Int, count: Long, valueOrOffset: Long) {
            ifdBuf.putShort(tag.toShort())
            ifdBuf.putShort(type.toShort())
            ifdBuf.putLong(count)
            ifdBuf.putLong(valueOrOffset)
        }

        val typeAscii = 2
        val typeShort = 3
        val typeLong = 4
        val typeLong8 = 16

        // 256 ImageWidth
        putEntry(256, typeLong, 1L, width.toLong())
        // 257 ImageLength
        putEntry(257, typeLong, 1L, rowsWritten.toLong())
        // 258 BitsPerSample (3 x SHORT fits in 6 bytes <= 8 bytes inline in BigTIFF!)
        val inlineBps = (8L) or (8L shl 16) or (8L shl 32)
        putEntry(258, typeShort, 3L, inlineBps)
        // 259 Compression = 1 (None)
        putEntry(259, typeShort, 1L, 1L)
        // 262 PhotometricInterpretation = 2 (RGB)
        putEntry(262, typeShort, 1L, 2L)
        // 273 StripOffsets
        if (stripOffsets.size == 1) {
            putEntry(273, typeLong8, 1L, stripOffsets[0])
        } else {
            putEntry(273, typeLong8, stripOffsets.size.toLong(), offsetsArrayPos)
        }
        // 277 SamplesPerPixel = 3
        putEntry(277, typeShort, 1L, 3L)
        // 278 RowsPerStrip
        putEntry(278, typeLong, 1L, rowsPerStrip.toLong())
        // 279 StripByteCounts
        if (stripByteCounts.size == 1) {
            putEntry(279, typeLong8, 1L, stripByteCounts[0])
        } else {
            putEntry(279, typeLong8, stripByteCounts.size.toLong(), countsArrayPos)
        }
        // 305 Software
        putEntry(305, typeAscii, softwareTag.size.toLong(), softwarePos)

        // Next IFD offset = 0
        ifdBuf.putLong(0L)
        raf.write(ifdBuf.array())

        // Patch 64-bit IFD offset in BigTIFF header at byte 8
        raf.seek(8L)
        val patch = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(ifdOffset)
        raf.write(patch.array())
    }
}
