package com.s23ultra.gigacam.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private val cameraViewModel: CameraViewModel by viewModels()
    private var hasCameraPermission by mutableStateOf(false)

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        hasCameraPermission = grants[Manifest.permission.CAMERA] == true
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        hasCameraPermission = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasCameraPermission) {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.CAMERA,
                    Manifest.permission.READ_MEDIA_IMAGES
                )
            )
        }

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF38BDF8),
                    secondary = Color(0xFFF59E0B),
                    background = Color.Black,
                    surface = Color(0xFF0B1120)
                )
            ) {
                var showGigaViewer by remember { mutableStateOf(false) }
                val progress by cameraViewModel.captureProgress.collectAsState()
                val settings by cameraViewModel.settings.collectAsState()

                if (!hasCameraPermission) {
                    Box(
                        modifier = Modifier.fillMaxSize().background(Color.Black),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                            Text(
                                "S23 Ultra GigaCam",
                                color = Color(0xFFF59E0B),
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                "برای دسترسی به لنزهای ۲۰۰ مگاپیکسلی، تله‌فوتو ۳x و پریسکوپ ۱۰x، دسترسی دوربین را تایید کنید.",
                                color = Color.White,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(18.dp))
                            Button(onClick = {
                                permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
                            }) {
                                Text("فعال‌سازی دسترسی دوربین")
                            }
                        }
                    }
                } else if (showGigaViewer) {
                    GigaViewerScreen(
                        previewPath = progress.lastPreviewPath,
                        dziPath = progress.lastDziPath,
                        bigTiffPath = progress.lastBigTiffPath,
                        resolutionLabel = settings.resolutionPreset.label,
                        onBack = { showGigaViewer = false }
                    )
                } else {
                    CameraScreen(
                        viewModel = cameraViewModel,
                        onOpenGigaViewer = { showGigaViewer = true }
                    )
                }
            }
        }
    }
}
