package com.s23ultra.gigacam.ui

import android.app.Application
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.view.Surface
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.s23ultra.gigacam.camera.ImuGridTracker
import com.s23ultra.gigacam.camera.ProCamera2Controller
import com.s23ultra.gigacam.domain.*
import com.s23ultra.gigacam.processing.AiEnhancementEngine
import com.s23ultra.gigacam.processing.UltraResolutionEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

data class GuidedMatrixState(
    val active: Boolean = false,
    val targets: List<MatrixTileTarget> = emptyList(),
    val currentIndex: Int = 0,
    val relYawDeg: Float = 0f,
    val relPitchDeg: Float = 0f,
    val isAlignedAndSteady: Boolean = false
)

class CameraViewModel(application: Application) : AndroidViewModel(application) {

    private val _settings = MutableStateFlow(ProCameraSettings())
    val settings: StateFlow<ProCameraSettings> = _settings.asStateFlow()

    private val _telemetry = MutableStateFlow(LiveTelemetry())
    val telemetry: StateFlow<LiveTelemetry> = _telemetry.asStateFlow()

    private val _captureProgress = MutableStateFlow(CaptureProgress())
    val captureProgress: StateFlow<CaptureProgress> = _captureProgress.asStateFlow()

    private val _matrixState = MutableStateFlow(GuidedMatrixState())
    val matrixState: StateFlow<GuidedMatrixState> = _matrixState.asStateFlow()

    private val aiEngine = AiEnhancementEngine(application)
    private val ultraEngine = UltraResolutionEngine(application, aiEngine)
    private val imuTracker = ImuGridTracker(application)

    private val cameraController = ProCamera2Controller(application) { hist, zebra, sharpness ->
        _telemetry.update {
            it.copy(
                histogramLuma = hist,
                zebraClipRatio = zebra,
                focusSharpnessScore = sharpness
            )
        }
    }

    private var activeSurface: Surface? = null
    private var guidedMatrixJob: Job? = null
    private var capturedMatrixFiles: Array<Array<File?>>? = null

    val isNeuralOnnxLoaded: Boolean get() = aiEngine.isNeuralModelLoaded

    init {
        viewModelScope.launch(Dispatchers.IO) {
            aiEngine.tryLoadNeuralModel(useNpu = true)
            refreshSystemHealth()
        }
        imuTracker.start { yaw, pitch, roll ->
            _telemetry.update { it.copy(yawDeg = yaw, pitchDeg = pitch, rollDeg = roll) }
            val ms = _matrixState.value
            if (ms.active && ms.currentIndex < ms.targets.size) {
                val target = ms.targets[ms.currentIndex]
                val locked = imuTracker.isLockedOnTarget(target)
                _matrixState.update {
                    it.copy(
                        relYawDeg = imuTracker.relativeYawDeg(),
                        relPitchDeg = imuTracker.relativePitchDeg(),
                        isAlignedAndSteady = locked
                    )
                }
            }
        }
    }

    fun attachPreviewSurface(surface: Surface) {
        activeSurface = surface
        viewModelScope.launch {
            runCatching {
                cameraController.openLens(_settings.value.selectedLens, surface, _settings.value)
            }.onFailure { err ->
                _captureProgress.update { it.copy(errorMessage = "خطای دوربین: ${err.message}") }
            }
        }
    }

    fun detachPreviewSurface() {
        activeSurface = null
        cameraController.closeCamera()
    }

    fun selectLens(lens: S23UltraLens) {
        _settings.update { it.copy(selectedLens = lens) }
        activeSurface?.let { surface ->
            viewModelScope.launch {
                runCatching { cameraController.openLens(lens, surface, _settings.value) }
            }
        }
    }

    fun selectResolutionPreset(preset: ResolutionPreset) {
        _settings.update {
            it.copy(
                resolutionPreset = preset,
                shootingMode = ShootingMode.ULTRA_MP
            )
        }
        refreshSystemHealth()
    }

    fun selectShootingMode(mode: ShootingMode) {
        _settings.update { current ->
            val updatedAi = if (mode == ShootingMode.AI_MAX) {
                current.aiConfig.copy(enabled = true, preset = AiPreset.ULTRA_CLARITY)
            } else current.aiConfig
            current.copy(shootingMode = mode, aiConfig = updatedAi)
        }
    }

    fun updateSettings(transform: (ProCameraSettings) -> ProCameraSettings) {
        _settings.update(transform)
        cameraController.updatePreviewSettings(_settings.value)
    }

    fun updateAiConfig(transform: (AiEnhanceConfig) -> AiEnhanceConfig) {
        _settings.update { it.copy(aiConfig = transform(it.aiConfig)) }
    }

    fun clearError() {
        _captureProgress.update { it.copy(errorMessage = null) }
    }

    /**
     * Main Shutter Action: dispatches to the optimal pipeline for the selected mode & MP preset.
     */
    fun onShutterPressed() {
        if (_captureProgress.value.isCapturing) return
        val cfg = _settings.value

        // Pre-flight storage check for Gigapixel outputs
        refreshSystemHealth()
        val requiredGb = (cfg.resolutionPreset.estimatedDiskMb * 1.4) / 1024.0
        if (cfg.shootingMode == ShootingMode.ULTRA_MP && _telemetry.value.freeStorageGb < requiredGb) {
            _captureProgress.update {
                it.copy(
                    errorMessage = "فضای ذخیره‌سازی کافی نیست! برای حالت ${cfg.resolutionPreset.label} حداقل %.1f گیگابایت فضای خالی نیاز است."
                        .format(requiredGb)
                )
            }
            return
        }

        when (cfg.shootingMode) {
            ShootingMode.ULTRA_MP -> {
                if (cfg.resolutionPreset.strategy == CaptureStrategy.GUIDED_GIGAPIXEL_MATRIX) {
                    startGuidedGigapixelCapture(cfg)
                } else {
                    runMfsrBurstCapture(cfg)
                }
            }
            ShootingMode.PRO_MANUAL, ShootingMode.AI_MAX -> runMfsrBurstCapture(
                cfg.copy(
                    resolutionPreset = if (cfg.shootingMode == ShootingMode.AI_MAX) ResolutionPreset.MP_300
                    else ResolutionPreset.MP_200
                )
            )
            ShootingMode.HDR_BRACKET -> runHdrBracketCapture(cfg)
            ShootingMode.FOCUS_STACK -> runFocusStackCapture(cfg)
            ShootingMode.ASTRO_NIGHT -> runAstroStackCapture(cfg)
        }
    }

    private fun runMfsrBurstCapture(cfg: ProCameraSettings) {
        viewModelScope.launch {
            val preset = cfg.resolutionPreset
            _captureProgress.value = CaptureProgress(
                isCapturing = true,
                stageTitleFa = "ثبت ${preset.burstFramesPerTile} فریم پیاپی برای ${preset.label}...",
                progressFraction = 0.05f,
                totalTiles = preset.burstFramesPerTile
            )
            runCatching {
                val frames = cameraController.captureBurst(
                    frameCount = preset.burstFramesPerTile,
                    settings = cfg
                ) { idx, total ->
                    _captureProgress.update {
                        it.copy(
                            stageTitleFa = "ثبت فریم $idx از $total (${preset.label})...",
                            progressFraction = 0.05f + 0.15f * (idx.toFloat() / total),
                            currentTileIndex = idx
                        )
                    }
                }
                val result = ultraEngine.processMfsrBurst(
                    frames = frames,
                    preset = preset,
                    aiConfig = cfg.aiConfig
                ) { stage, frac ->
                    _captureProgress.update {
                        it.copy(stageTitleFa = stage, progressFraction = frac)
                    }
                }
                _captureProgress.value = CaptureProgress(
                    isCapturing = false,
                    stageTitleFa = "ذخیره شد: %.0f MP (${result.finalWidth}×${result.finalHeight})".format(result.actualMegapixels),
                    progressFraction = 1.0f,
                    lastOutputDir = result.outputDir.absolutePath,
                    lastPreviewPath = result.previewJpeg.absolutePath,
                    lastDziPath = result.dziManifestFile?.absolutePath,
                    lastBigTiffPath = result.bigTiffFile?.absolutePath
                )
            }.onFailure { err ->
                _captureProgress.value = CaptureProgress(
                    isCapturing = false,
                    errorMessage = "خطا در ثبت ${preset.label}: ${err.message}"
                )
            }
        }
    }

    /**
     * Launches the interactive Gyroscope-Guided Gigapixel Matrix capture for 800/1000/2000/5000 MP.
     * Automatically triggers each tile when the crosshair locks onto the target dot & hand is steady.
     */
    private fun startGuidedGigapixelCapture(cfg: ProCameraSettings) {
        val preset = cfg.resolutionPreset
        imuTracker.lockAnchorOrigin()
        val targets = imuTracker.generateMatrixTargets(preset, cfg.selectedLens)
        val tempDir = File(getApplication<Application>().cacheDir, "matrix_${System.currentTimeMillis()}").apply { mkdirs() }
        capturedMatrixFiles = Array(preset.gridRows) { arrayOfNulls<File>(preset.gridCols) }

        _matrixState.value = GuidedMatrixState(
            active = true,
            targets = targets,
            currentIndex = 0
        )

        guidedMatrixJob?.cancel()
        guidedMatrixJob = viewModelScope.launch {
            for (idx in targets.indices) {
                val target = targets[idx]
                _matrixState.update { it.copy(currentIndex = idx) }

                // Wait until user aligns crosshair with target reticle (auto-lock)
                while (_matrixState.value.active && !imuTracker.isLockedOnTarget(target, toleranceDeg = 1.6f)) {
                    delay(45L)
                }
                if (!_matrixState.value.active) return@launch

                // Steady settle delay (120ms) then capture tile
                delay(120L)
                val frame = cameraController.captureSingleFrame(cfg)
                val tileFile = File(tempDir, "tile_${target.row}_${target.col}.jpg")
                frame.jpegBytes?.let { bytes ->
                    FileOutputStream(tileFile).use { it.write(bytes) }
                }
                capturedMatrixFiles?.get(target.row)?.set(target.col, tileFile)

                val updatedTargets = _matrixState.value.targets.toMutableList()
                updatedTargets[idx] = target.copy(captured = true, filePath = tileFile.absolutePath)
                _matrixState.update { it.copy(targets = updatedTargets) }
            }

            // All tiles captured -> run Out-of-Core Gigapixel Stitcher + AI + BigTIFF/DZI
            _matrixState.update { it.copy(active = false) }
            _captureProgress.value = CaptureProgress(
                isCapturing = true,
                stageTitleFa = "شروع دوخت گیگاپیکسلی ${preset.label} (بدون پر کردن رم)...",
                progressFraction = 0.05f,
                totalTiles = targets.size
            )

            runCatching {
                val result = ultraEngine.stitchGigapixelMatrix(
                    tileFilesGrid = capturedMatrixFiles!!,
                    preset = preset,
                    aiConfig = cfg.aiConfig
                ) { stage, frac ->
                    _captureProgress.update { it.copy(stageTitleFa = stage, progressFraction = frac) }
                }
                tempDir.deleteRecursively()
                _captureProgress.value = CaptureProgress(
                    isCapturing = false,
                    stageTitleFa = "تکمیل شد: ${preset.label} (${result.finalWidth}×${result.finalHeight})",
                    progressFraction = 1.0f,
                    lastOutputDir = result.outputDir.absolutePath,
                    lastPreviewPath = result.previewJpeg.absolutePath,
                    lastDziPath = result.dziManifestFile?.absolutePath,
                    lastBigTiffPath = result.bigTiffFile?.absolutePath
                )
            }.onFailure { err ->
                tempDir.deleteRecursively()
                _captureProgress.value = CaptureProgress(
                    isCapturing = false,
                    errorMessage = "خطا در پردازش گیگاپیکسلی: ${err.message}"
                )
            }
        }
    }

    fun cancelGuidedMatrix() {
        guidedMatrixJob?.cancel()
        _matrixState.value = GuidedMatrixState(active = false)
    }

    private fun runHdrBracketCapture(cfg: ProCameraSettings) {
        viewModelScope.launch {
            _captureProgress.value = CaptureProgress(isCapturing = true, stageTitleFa = "ثبت براکتینگ HDR+...", progressFraction = 0.1f)
            runCatching {
                val frames = cameraController.captureExposureBracket(cfg) { step, total ->
                    _captureProgress.update { it.copy(stageTitleFa = "نوردهی $step از $total...", progressFraction = 0.1f + 0.4f * step / total) }
                }
                _captureProgress.update { it.copy(stageTitleFa = "ترکیب HDR و بهینه‌سازی AI...", progressFraction = 0.65f) }
                val res = ultraEngine.fuseHdrBracket(frames, cfg.aiConfig)
                _captureProgress.value = CaptureProgress(
                    isCapturing = false,
                    stageTitleFa = "HDR+ ذخیره شد",
                    progressFraction = 1f,
                    lastPreviewPath = res.previewJpeg.absolutePath
                )
            }.onFailure { e ->
                _captureProgress.value = CaptureProgress(errorMessage = "خطای HDR: ${e.message}")
            }
        }
    }

    private fun runFocusStackCapture(cfg: ProCameraSettings) {
        viewModelScope.launch {
            _captureProgress.value = CaptureProgress(isCapturing = true, stageTitleFa = "جاروب فوکوس از نزدیک به بی‌نهایت...", progressFraction = 0.1f)
            runCatching {
                val frames = cameraController.captureFocusStack(cfg) { step, total ->
                    _captureProgress.update { it.copy(stageTitleFa = "پله فوکوس $step از $total...", progressFraction = 0.1f + 0.5f * step / total) }
                }
                _captureProgress.update { it.copy(stageTitleFa = "ادغام شارپ‌ترین پیکسل‌ها (Focus Stack)...", progressFraction = 0.75f) }
                val res = ultraEngine.mergeFocusStack(frames, cfg.aiConfig)
                _captureProgress.value = CaptureProgress(
                    isCapturing = false,
                    stageTitleFa = "Focus Stack ذخیره شد",
                    progressFraction = 1f,
                    lastPreviewPath = res.previewJpeg.absolutePath
                )
            }.onFailure { e ->
                _captureProgress.value = CaptureProgress(errorMessage = "خطای Focus Stack: ${e.message}")
            }
        }
    }

    private fun runAstroStackCapture(cfg: ProCameraSettings) {
        val astroSettings = cfg.copy(
            resolutionPreset = ResolutionPreset.MP_300,
            aiConfig = cfg.aiConfig.copy(enabled = true, preset = AiPreset.NIGHT_DENOISE)
        )
        runMfsrBurstCapture(astroSettings)
    }

    private fun refreshSystemHealth() {
        val path = getApplication<Application>().getExternalFilesDir(Environment.DIRECTORY_PICTURES)
            ?: getApplication<Application>().filesDir
        val stat = StatFs(path.absolutePath)
        val freeGb = stat.availableBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)

        val batteryIntent = getApplication<Application>().registerReceiver(
            null,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        )
        val tempTenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 300) ?: 300
        _telemetry.update { it.copy(freeStorageGb = freeGb, batteryTempC = tempTenths / 10.0f) }
    }

    override fun onCleared() {
        super.onCleared()
        imuTracker.stop()
        cameraController.release()
        aiEngine.release()
    }
}
