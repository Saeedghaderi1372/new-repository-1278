package com.s23ultra.gigacam.domain

/**
 * Capture strategies tailored to the Samsung Galaxy S23 Ultra (ISOCELL HP2 200MP + 10x Periscope).
 */
enum class CaptureStrategy(val titleFa: String, val titleEn: String) {
    NATIVE_HP2("سنسور ۲۰۰ مگاپیکسلی مستقیم", "Native 200MP Sensor"),
    MFSR_AI_BURST("سوپررزولوشن چندفریمی + AI", "Multi-Frame Super-Res + AI"),
    GUIDED_GIGAPIXEL_MATRIX("ماتریس گیگاپیکسلی با ژیروسکوپ + AI", "Gyro-Guided Gigapixel Matrix + AI")
}

enum class OutputContainer(val extension: String, val label: String) {
    JPEG_ULTRA("jpg", "JPEG Ultra (Max Quality)"),
    RAW_DNG("dng", "12-bit RAW DNG"),
    BIGTIFF_AND_DZI("tif", "64-bit BigTIFF + DeepZoom Pyramid")
}

/**
 * Complete resolution presets requested: 200MP (native reference), 300MP, 500MP, 800MP, 1000MP, 2000MP, 5000MP.
 * Every preset specifies exact 4:3 dimensions, capture matrix grid (cols x rows), burst frames per tile,
 * recommended S23 Ultra lens, output container, and realistic disk footprint.
 */
enum class ResolutionPreset(
    val megapixels: Int,
    val label: String,
    val targetWidth: Int,
    val targetHeight: Int,
    val strategy: CaptureStrategy,
    val gridCols: Int,
    val gridRows: Int,
    val overlapRatio: Float,
    val burstFramesPerTile: Int,
    val aiUpscaleFactor: Float,
    val recommendedLens: S23UltraLens,
    val outputContainer: OutputContainer,
    val estimatedDiskMb: Int,
    val descriptionFa: String
) {
    MP_200(
        megapixels = 200,
        label = "200 MP",
        targetWidth = 16320,
        targetHeight = 12240,
        strategy = CaptureStrategy.NATIVE_HP2,
        gridCols = 1,
        gridRows = 1,
        overlapRatio = 0.0f,
        burstFramesPerTile = 1,
        aiUpscaleFactor = 1.0f,
        recommendedLens = S23UltraLens.WIDE_1X_200MP,
        outputContainer = OutputContainer.JPEG_ULTRA,
        estimatedDiskMb = 45,
        descriptionFa = "رزولوشن بومی سنسور ISOCELL HP2"
    ),
    MP_300(
        megapixels = 300,
        label = "300 MP",
        targetWidth = 20000,
        targetHeight = 15000,
        strategy = CaptureStrategy.MFSR_AI_BURST,
        gridCols = 1,
        gridRows = 1,
        overlapRatio = 0.0f,
        burstFramesPerTile = 8,
        aiUpscaleFactor = 1.25f,
        recommendedLens = S23UltraLens.WIDE_1X_200MP,
        outputContainer = OutputContainer.JPEG_ULTRA,
        estimatedDiskMb = 95,
        descriptionFa = "ترکیب ۸ فریم زیرپیکسلی + بازسازی جزئیات AI"
    ),
    MP_500(
        megapixels = 500,
        label = "500 MP",
        targetWidth = 25820,
        targetHeight = 19365,
        strategy = CaptureStrategy.MFSR_AI_BURST,
        gridCols = 2,
        gridRows = 2,
        overlapRatio = 0.25f,
        burstFramesPerTile = 6,
        aiUpscaleFactor = 1.25f,
        recommendedLens = S23UltraLens.WIDE_1X_200MP,
        outputContainer = OutputContainer.JPEG_ULTRA,
        estimatedDiskMb = 180,
        descriptionFa = "ماتریس ۲×۲ یا ترکیب ۱۶ فریم MFSR + هوش مصنوعی"
    ),
    MP_800(
        megapixels = 800,
        label = "800 MP",
        targetWidth = 32660,
        targetHeight = 24495,
        strategy = CaptureStrategy.GUIDED_GIGAPIXEL_MATRIX,
        gridCols = 3,
        gridRows = 3,
        overlapRatio = 0.28f,
        burstFramesPerTile = 4,
        aiUpscaleFactor = 1.25f,
        recommendedLens = S23UltraLens.TELEPHOTO_3X,
        outputContainer = OutputContainer.BIGTIFF_AND_DZI,
        estimatedDiskMb = 520,
        descriptionFa = "ماتریس ۳×۳ با لنز تله ۳x یا سنسور ۲۰۰MP + دوخت هوشمند"
    ),
    MP_1000(
        megapixels = 1000,
        label = "1000 MP",
        targetWidth = 36515,
        targetHeight = 27386,
        strategy = CaptureStrategy.GUIDED_GIGAPIXEL_MATRIX,
        gridCols = 4,
        gridRows = 3,
        overlapRatio = 0.28f,
        burstFramesPerTile = 3,
        aiUpscaleFactor = 1.5f,
        recommendedLens = S23UltraLens.TELEPHOTO_3X,
        outputContainer = OutputContainer.BIGTIFF_AND_DZI,
        estimatedDiskMb = 850,
        descriptionFa = "۱ گیگاپیکسل واقعی با ماتریس ۴×۳ و پردازش کاشی‌ای بدون اشغال رم"
    ),
    MP_2000(
        megapixels = 2000,
        label = "2000 MP",
        targetWidth = 51640,
        targetHeight = 38730,
        strategy = CaptureStrategy.GUIDED_GIGAPIXEL_MATRIX,
        gridCols = 5,
        gridRows = 4,
        overlapRatio = 0.30f,
        burstFramesPerTile = 2,
        aiUpscaleFactor = 1.5f,
        recommendedLens = S23UltraLens.PERISCOPE_10X,
        outputContainer = OutputContainer.BIGTIFF_AND_DZI,
        estimatedDiskMb = 1850,
        descriptionFa = "۲ گیگاپیکسل واقعی با لنز پریسکوپ ۱۰x + BigTIFF + DeepZoom"
    ),
    MP_5000(
        megapixels = 5000,
        label = "5000 MP",
        targetWidth = 81650,
        targetHeight = 61238,
        strategy = CaptureStrategy.GUIDED_GIGAPIXEL_MATRIX,
        gridCols = 8,
        gridRows = 6,
        overlapRatio = 0.30f,
        burstFramesPerTile = 2,
        aiUpscaleFactor = 2.0f,
        recommendedLens = S23UltraLens.PERISCOPE_10X,
        outputContainer = OutputContainer.BIGTIFF_AND_DZI,
        estimatedDiskMb = 4900,
        descriptionFa = "۵ گیگاپیکسل (فوق‌وضوح) - خروجی BigTIFF 64-bit + نمایشگر DeepZoom (فراتر از سقف استاندارد JPEG)"
    );

    val totalTiles: Int get() = gridCols * gridRows
    val exactMegapixels: Double get() = (targetWidth.toDouble() * targetHeight.toDouble()) / 1_000_000.0
    val exceedsStandardJpegLimit: Boolean get() = targetWidth > 65535 || targetHeight > 65535
}

enum class S23UltraLens(
    val zoomLabel: String,
    val focalLengthEqMm: Int,
    val aperture: Float,
    val nativeMp: Int,
    val horizontalFovDeg: Float,
    val verticalFovDeg: Float
) {
    ULTRAWIDE_0_6X("0.6x", 13, 2.2f, 12, 108.0f, 86.0f),
    WIDE_1X_200MP("1x", 23, 1.7f, 200, 74.0f, 58.0f),
    TELEPHOTO_3X("3x", 69, 2.4f, 10, 29.0f, 22.0f),
    PERISCOPE_10X("10x", 230, 4.9f, 10, 9.2f, 6.9f)
}

enum class ShootingMode(val labelFa: String, val labelEn: String) {
    ULTRA_MP("فوق‌مگاپیکسل", "ULTRA MP"),
    PRO_MANUAL("حرفه‌ای PRO", "PRO"),
    AI_MAX("هوش مصنوعی AI", "AI MAX"),
    HDR_BRACKET("HDR حرفه‌ای", "HDR+"),
    FOCUS_STACK("فوکوس استک", "FOCUS STACK"),
    ASTRO_NIGHT("عکاسی نجومی", "ASTRO")
}

enum class GridOverlayType { NONE, RULE_OF_THIRDS, GOLDEN_RATIO, DIAGONAL, CROSSHAIR }
enum class MeteringMode { MATRIX, CENTER_WEIGHTED, SPOT }

enum class AiPreset(val labelFa: String, val descFa: String) {
    OFF("خاموش", "پردازش خام بدون دخالت AI"),
    NATURAL_PRO("طبیعی حرفه‌ای", "حذف نویز هوشمند و حفظ بافت طبیعی"),
    ULTRA_CLARITY("حداکثر وضوح و شارپنس", "بازسازی بافت، رفع تاری اپتیکال و Super-Res 2x"),
    NIGHT_DENOISE("نجومی و نور کم", "حذف نویز عمیق و بازیابی جزئیات سایه"),
    TELE_100X_RESTORE("بازسازی زوم تله‌فوتو", "اصلاح اعوجاج و شارپنس لنز ۱۰x و زوم بالا"),
    DYNAMIC_HDR("رنگ و نور سینمایی HDR", "تون‌مپینگ ACES Filmic و گستره دینامیکی حداکثری")
}

data class AiEnhanceConfig(
    val enabled: Boolean = true,
    val preset: AiPreset = AiPreset.ULTRA_CLARITY,
    val denoiseStrength: Float = 0.45f,
    val deblurStrength: Float = 0.65f,
    val hdrStrength: Float = 0.50f,
    val microContrast: Float = 0.40f,
    val neuralSuperResEnabled: Boolean = true,
    val useHexagonNpu: Boolean = true
)

data class ProCameraSettings(
    val selectedLens: S23UltraLens = S23UltraLens.WIDE_1X_200MP,
    val shootingMode: ShootingMode = ShootingMode.ULTRA_MP,
    val resolutionPreset: ResolutionPreset = ResolutionPreset.MP_300,
    val manualExposure: Boolean = false,
    val iso: Int = 100,
    val shutterSpeedNs: Long = 10_000_000L, // 1/100s
    val evCompensation: Int = 0,
    val manualFocus: Boolean = false,
    val focusDistanceDiopters: Float = 0.0f, // 0 = infinity, up to 10 = macro
    val manualWhiteBalance: Boolean = false,
    val whiteBalanceKelvin: Int = 5500,
    val meteringMode: MeteringMode = MeteringMode.MATRIX,
    val captureRawDng: Boolean = false,
    val oisEnabled: Boolean = true,
    val aeAfLocked: Boolean = false,
    val showHistogram: Boolean = true,
    val showFocusPeaking: Boolean = true,
    val showZebraStripes: Boolean = false,
    val showLeveler: Boolean = true,
    val gridOverlay: GridOverlayType = GridOverlayType.RULE_OF_THIRDS,
    val hdrBracketFrames: Int = 3,
    val hdrBracketEvStep: Float = 2.0f,
    val focusStackSteps: Int = 7,
    val astroFrameCount: Int = 12,
    val aiConfig: AiEnhanceConfig = AiEnhanceConfig()
)

data class LiveTelemetry(
    val histogramLuma: IntArray = IntArray(256),
    val zebraClipRatio: Float = 0.0f,
    val focusSharpnessScore: Float = 0.0f,
    val pitchDeg: Float = 0.0f,
    val rollDeg: Float = 0.0f,
    val yawDeg: Float = 0.0f,
    val freeStorageGb: Double = 0.0,
    val batteryTempC: Float = 30.0f
)

data class MatrixTileTarget(
    val col: Int,
    val row: Int,
    val targetYawDeg: Float,
    val targetPitchDeg: Float,
    val captured: Boolean = false,
    val filePath: String? = null
)

data class CaptureProgress(
    val isCapturing: Boolean = false,
    val stageTitleFa: String = "",
    val progressFraction: Float = 0.0f,
    val currentTileIndex: Int = 0,
    val totalTiles: Int = 1,
    val lastOutputDir: String? = null,
    val lastPreviewPath: String? = null,
    val lastDziPath: String? = null,
    val lastBigTiffPath: String? = null,
    val errorMessage: String? = null
)
