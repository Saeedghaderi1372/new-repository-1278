package com.s23ultra.gigacam.processing

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import com.s23ultra.gigacam.domain.AiEnhanceConfig
import com.s23ultra.gigacam.domain.AiPreset
import java.io.File
import java.nio.FloatBuffer
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Dual-Tier On-Device AI Enhancement & Super-Resolution Engine for Snapdragon 8 Gen 2:
 *
 * Tier 1 (Deep Learning Neural SR via ONNX Runtime + NNAPI/Hexagon NPU):
 *   If a Real-ESRGAN / SwinIR / NAFNet ONNX model (`realesrgan_x2.onnx` or `realesrgan_x4.onnx`)
 *   is present in app assets or external models directory, runs overlap-tiled neural inference
 *   with Hann-window feathering to guarantee zero seam artifacts even at 5000 MP.
 *
 * Tier 2 (Native C++ Computational Restoration Pipeline):
 *   Always available out-of-the-box with zero external weights required:
 *   Edge-preserving bilateral chroma/luma denoise + optical PSF deconvolution sharpening +
 *   micro-contrast local curve + ACES Filmic HDR tone mapping.
 */
class AiEnhancementEngine(private val context: Context) {

    private var ortEnv: OrtEnvironment? = null
    private var srSession: OrtSession? = null
    private var activeModelScale: Int = 1

    val isNeuralModelLoaded: Boolean get() = srSession != null

    /**
     * Loads an optional ONNX Super-Resolution model (e.g., realesrgan_x2.onnx) with NNAPI
     * hardware acceleration targeting Snapdragon 8 Gen 2 Hexagon NPU / Adreno 740 GPU.
     */
    fun tryLoadNeuralModel(useNpu: Boolean = true): Boolean {
        if (srSession != null) return true
        val modelFile = findModelFile("realesrgan_x2.onnx")
            ?: findModelFile("swinir_x2.onnx")
            ?: return false

        return runCatching {
            val env = OrtEnvironment.getEnvironment()
            val opts = OrtSession.SessionOptions().apply {
                setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
                setIntraOpNumThreads(4)
                if (useNpu) {
                    runCatching { addNnapi() }
                }
            }
            ortEnv = env
            srSession = env.createSession(modelFile.absolutePath, opts)
            activeModelScale = 2
            true
        }.getOrDefault(false)
    }

    private fun findModelFile(name: String): File? {
        val extDir = File(context.getExternalFilesDir(null), "models/$name")
        if (extDir.exists() && extDir.length() > 1024) return extDir

        val internalCopy = File(context.filesDir, "models/$name")
        if (internalCopy.exists() && internalCopy.length() > 1024) return internalCopy

        return runCatching {
            context.assets.open("models/$name").use { input ->
                internalCopy.parentFile?.mkdirs()
                internalCopy.outputStream().use { output -> input.copyTo(output) }
            }
            internalCopy
        }.getOrNull()
    }

    /**
     * Enhances a packed RGB tile in-place or with neural super-resolution upscale.
     * Always operates tile-by-tile (e.g. 512x512 or 1024x1024) to keep peak RAM minimal.
     */
    fun enhanceRgbTile(
        rgb: ByteArray,
        width: Int,
        height: Int,
        config: AiEnhanceConfig,
        targetScale: Float = 1.0f
    ): Triple<ByteArray, Int, Int> {
        if (!config.enabled || config.preset == AiPreset.OFF) {
            return Triple(rgb, width, height)
        }

        val tuned = resolvePresetParams(config)
        var currentRgb = rgb
        var curW = width
        var curH = height

        // Step 1: Optional ONNX Neural Super-Resolution (2x) if model is present and upscale requested
        if (config.neuralSuperResEnabled && targetScale > 1.05f && tryLoadNeuralModel(config.useHexagonNpu)) {
            val sr = runOnnxSuperResTiled(currentRgb, curW, curH, tileSize = 192, overlap = 16)
            if (sr != null) {
                currentRgb = sr.first
                curW = sr.second
                curH = sr.third
            }
        }

        // Step 2: Native C++ Computational Restoration (Denoise + Deblur + ACES HDR + Micro-Contrast)
        NativeGigaEngine.nativeEnhanceTileRgb(
            rgbTile = currentRgb,
            width = curW,
            height = curH,
            denoiseStrength = tuned.denoiseStrength,
            deblurStrength = tuned.deblurStrength,
            hdrStrength = tuned.hdrStrength,
            microContrast = tuned.microContrast
        )

        return Triple(currentRgb, curW, curH)
    }

    /**
     * Overlap-tile ONNX Runtime neural super-resolution with 2D Hann feather blending.
     */
    private fun runOnnxSuperResTiled(
        rgb: ByteArray,
        width: Int,
        height: Int,
        tileSize: Int,
        overlap: Int
    ): Triple<ByteArray, Int, Int>? {
        val env = ortEnv ?: return null
        val session = srSession ?: return null
        val scale = activeModelScale
        val outW = width * scale
        val outH = height * scale

        val accum = FloatArray(outW * outH * 3)
        val weight = FloatArray(outW * outH)
        val stride = (tileSize - overlap * 2).coerceAtLeast(32)
        val inputName = session.inputNames.first()

        var y = 0
        while (y < height) {
            var x = 0
            while (x < width) {
                val tw = min(tileSize, width - x)
                val th = min(tileSize, height - y)

                // Convert RGB [0..255] -> NCHW float [0..1]
                val planeSize = tw * th
                val inputData = FloatArray(3 * planeSize)
                for (ty in 0 until th) {
                    for (tx in 0 until tw) {
                        val srcIdx = ((y + ty) * width + (x + tx)) * 3
                        val dstIdx = ty * tw + tx
                        inputData[dstIdx] = (rgb[srcIdx].toInt() and 0xFF) / 255.0f
                        inputData[planeSize + dstIdx] = (rgb[srcIdx + 1].toInt() and 0xFF) / 255.0f
                        inputData[2 * planeSize + dstIdx] = (rgb[srcIdx + 2].toInt() and 0xFF) / 255.0f
                    }
                }

                val tensor = OnnxTensor.createTensor(
                    env,
                    FloatBuffer.wrap(inputData),
                    longArrayOf(1, 3, th.toLong(), tw.toLong())
                )
                tensor.use { t ->
                    session.run(mapOf(inputName to t)).use { results ->
                        val outArr = results[0].value as Array<Array<Array<FloatArray>>>
                        val stW = tw * scale
                        val stH = th * scale
                        val tileRgb = ByteArray(stW * stH * 3)
                        for (oy in 0 until stH) {
                            for (ox in 0 until stW) {
                                val idx = (oy * stW + ox) * 3
                                tileRgb[idx] = (outArr[0][0][oy][ox].coerceIn(0f, 1f) * 255f).roundToInt().toByte()
                                tileRgb[idx + 1] = (outArr[0][1][oy][ox].coerceIn(0f, 1f) * 255f).roundToInt().toByte()
                                tileRgb[idx + 2] = (outArr[0][2][oy][ox].coerceIn(0f, 1f) * 255f).roundToInt().toByte()
                            }
                        }
                        NativeGigaEngine.nativeBlendTileHann(
                            srcTileRgb = tileRgb,
                            tileW = stW,
                            tileH = stH,
                            dstAccumRgb = accum,
                            dstWeight = weight,
                            dstW = outW,
                            dstH = outH,
                            offsetX = x * scale,
                            offsetY = y * scale,
                            featherPx = overlap * scale
                        )
                    }
                }
                x += stride
            }
            y += stride
        }

        val outRgb = ByteArray(outW * outH * 3)
        for (i in 0 until outW * outH) {
            val invW = if (weight[i] > 1e-5f) 1.0f / weight[i] else 1.0f
            outRgb[i * 3] = (accum[i * 3] * invW).coerceIn(0f, 255f).roundToInt().toByte()
            outRgb[i * 3 + 1] = (accum[i * 3 + 1] * invW).coerceIn(0f, 255f).roundToInt().toByte()
            outRgb[i * 3 + 2] = (accum[i * 3 + 2] * invW).coerceIn(0f, 255f).roundToInt().toByte()
        }
        return Triple(outRgb, outW, outH)
    }

    fun enhanceBitmapPreview(bitmap: Bitmap, config: AiEnhanceConfig): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
        val rgb = ByteArray(w * h * 3)
        for (i in pixels.indices) {
            val p = pixels[i]
            rgb[i * 3] = ((p shr 16) and 0xFF).toByte()
            rgb[i * 3 + 1] = ((p shr 8) and 0xFF).toByte()
            rgb[i * 3 + 2] = (p and 0xFF).toByte()
        }
        val (enhanced, ew, eh) = enhanceRgbTile(rgb, w, h, config, targetScale = 1.0f)
        val outPixels = IntArray(ew * eh)
        for (i in outPixels.indices) {
            val r = enhanced[i * 3].toInt() and 0xFF
            val g = enhanced[i * 3 + 1].toInt() and 0xFF
            val b = enhanced[i * 3 + 2].toInt() and 0xFF
            outPixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }
        return Bitmap.createBitmap(outPixels, ew, eh, Bitmap.Config.ARGB_8888)
    }

    private fun resolvePresetParams(c: AiEnhanceConfig): AiEnhanceConfig = when (c.preset) {
        AiPreset.OFF -> c.copy(denoiseStrength = 0f, deblurStrength = 0f, hdrStrength = 0f, microContrast = 0f)
        AiPreset.NATURAL_PRO -> c.copy(denoiseStrength = 0.30f, deblurStrength = 0.40f, hdrStrength = 0.25f, microContrast = 0.25f)
        AiPreset.ULTRA_CLARITY -> c
        AiPreset.NIGHT_DENOISE -> c.copy(denoiseStrength = 0.85f, deblurStrength = 0.45f, hdrStrength = 0.70f, microContrast = 0.30f)
        AiPreset.TELE_100X_RESTORE -> c.copy(denoiseStrength = 0.65f, deblurStrength = 0.90f, hdrStrength = 0.45f, microContrast = 0.55f)
        AiPreset.DYNAMIC_HDR -> c.copy(denoiseStrength = 0.35f, deblurStrength = 0.55f, hdrStrength = 0.85f, microContrast = 0.50f)
    }

    fun release() {
        runCatching { srSession?.close() }
        srSession = null
    }
}
