package com.s23ultra.gigacam.camera

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import com.s23ultra.gigacam.domain.MatrixTileTarget
import com.s23ultra.gigacam.domain.ResolutionPreset
import com.s23ultra.gigacam.domain.S23UltraLens
import kotlin.math.abs
import kotlin.math.hypot

/**
 * High-frequency IMU (Rotation Vector + Gyroscope) tracker powering:
 * 1) 3D Electronic Horizon / Spirit Leveler (Pitch & Roll)
 * 2) Guided Gigapixel Matrix Capture (800MP, 1000MP, 2000MP, 5000MP)
 *    Computes angular reticle coordinates for every overlapping tile and auto-triggers shutter
 *    only when locked onto target with near-zero angular velocity (preventing motion blur).
 */
class ImuGridTracker(context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val rotationSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val gyroSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

    private val rotationMatrix = FloatArray(9)
    private val remappedMatrix = FloatArray(9)
    private val orientationAngles = FloatArray(3)

    @Volatile var currentYawDeg: Float = 0f; private set
    @Volatile var currentPitchDeg: Float = 0f; private set
    @Volatile var currentRollDeg: Float = 0f; private set
    @Volatile var angularVelocityRadSec: Float = 0f; private set

    private var anchorYawDeg: Float = 0f
    private var anchorPitchDeg: Float = 0f
    private var onOrientationUpdate: ((yaw: Float, pitch: Float, roll: Float) -> Unit)? = null

    fun start(listener: (yaw: Float, pitch: Float, roll: Float) -> Unit) {
        onOrientationUpdate = listener
        rotationSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        gyroSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    fun stop() {
        sensorManager.unregisterListener(this)
        onOrientationUpdate = null
    }

    fun lockAnchorOrigin() {
        anchorYawDeg = currentYawDeg
        anchorPitchDeg = currentPitchDeg
    }

    fun relativeYawDeg(): Float = normalizeAngleDeg(currentYawDeg - anchorYawDeg)
    fun relativePitchDeg(): Float = currentPitchDeg - anchorPitchDeg

    /**
     * Generates a serpentine (boustrophedon) grid of angular targets centered around the anchor pose,
     * spaced by the lens FOV * (1 - overlapRatio) so adjacent tiles overlap cleanly for stitching.
     */
    fun generateMatrixTargets(preset: ResolutionPreset, lens: S23UltraLens): List<MatrixTileTarget> {
        val stepYaw = lens.horizontalFovDeg * (1.0f - preset.overlapRatio)
        val stepPitch = lens.verticalFovDeg * (1.0f - preset.overlapRatio)

        val halfCols = (preset.gridCols - 1) / 2.0f
        val halfRows = (preset.gridRows - 1) / 2.0f

        val targets = mutableListOf<MatrixTileTarget>()
        for (row in 0 until preset.gridRows) {
            // Serpentine scan reduces hand movement distance between rows
            val cols = if (row % 2 == 0) (0 until preset.gridCols) else (preset.gridCols - 1 downTo 0)
            for (col in cols) {
                val targetYaw = (col - halfCols) * stepYaw
                val targetPitch = (halfRows - row) * stepPitch
                targets.add(
                    MatrixTileTarget(
                        col = col,
                        row = row,
                        targetYawDeg = targetYaw,
                        targetPitchDeg = targetPitch
                    )
                )
            }
        }
        return targets
    }

    /**
     * Returns true when the camera optical axis is aligned within tolerance of the target tile
     * and the user's hand is steady enough (< 0.08 rad/s) for tack-sharp capture.
     */
    fun isLockedOnTarget(target: MatrixTileTarget, toleranceDeg: Float = 1.2f): Boolean {
        val dyaw = abs(relativeYawDeg() - target.targetYawDeg)
        val dpitch = abs(relativePitchDeg() - target.targetPitchDeg)
        val angularError = hypot(dyaw.toDouble(), dpitch.toDouble()).toFloat()
        return angularError <= toleranceDeg && angularVelocityRadSec < 0.08f
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_ROTATION_VECTOR -> {
                SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                // Remap for portrait camera holding posture (Z pointing out the back lens)
                SensorManager.remapCoordinateSystem(
                    rotationMatrix,
                    SensorManager.AXIS_X,
                    SensorManager.AXIS_Z,
                    remappedMatrix
                )
                SensorManager.getOrientation(remappedMatrix, orientationAngles)
                currentYawDeg = Math.toDegrees(orientationAngles[0].toDouble()).toFloat()
                currentPitchDeg = Math.toDegrees(orientationAngles[1].toDouble()).toFloat()
                currentRollDeg = Math.toDegrees(orientationAngles[2].toDouble()).toFloat()
                onOrientationUpdate?.invoke(currentYawDeg, currentPitchDeg, currentRollDeg)
            }
            Sensor.TYPE_GYROSCOPE -> {
                val wx = event.values[0]
                val wy = event.values[1]
                val wz = event.values[2]
                angularVelocityRadSec = kotlin.math.sqrt(wx * wx + wy * wy + wz * wz)
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun normalizeAngleDeg(angle: Float): Float {
        var a = angle
        while (a > 180f) a -= 360f
        while (a < -180f) a += 360f
        return a
    }
}
