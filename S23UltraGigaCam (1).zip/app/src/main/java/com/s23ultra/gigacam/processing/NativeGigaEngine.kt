package com.s23ultra.gigacam.processing

import kotlin.math.*

/**
 * High-performance computational photography engine compiled by Android ART (64-bit ARMv9)
 * for Samsung Galaxy S23 Ultra (Snapdragon 8 Gen 2):
 * - Real-time Y-plane 256-bin histogram, zebra highlight clipping, and Sobel focus peaking
 * - Multi-Frame Super-Resolution (MFSR) Lanczos-3 sub-pixel drizzle with Huber ghost rejection
 * - Edge-preserving Bilateral Denoise + Optical PSF Deconvolution Sharpening + ACES Filmic HDR
 * - 2D Hann-window cosine feather blending for seamless out-of-core gigapixel stitching
 */
object NativeGigaEngine {

    private inline fun clamp01(v: Float): Float = when {
        v < 0f -> 0f
        v > 1f -> 1f
        else -> v
    }

    private inline fun clampByte(v: Float): Byte = when {
        v <= 0f -> 0.toByte()
        v >= 255f -> 255.toByte()
        else -> (v + 0.5f).toInt().toByte()
    }

    private inline fun acesFilmic(x: Float): Float {
        val a = 2.51f
        val b = 0.03f
        val c = 2.43f
        val d = 0.59f
        val e = 0.14f
        return clamp01((x * (a * x + b)) / (x * (c * x + d) + e))
    }

    private fun lanczos3(x: Float): Float {
        val ax = abs(x)
        if (ax < 1e-6f) return 1.0f
        if (ax >= 3.0f) return 0.0f
        val pix = Math.PI.toFloat() * x
        return (sin(pix) / pix) * (sin(pix / 3.0f) / (pix / 3.0f))
    }

    fun nativeAnalyzeYPlane(
        yBytes: ByteArray,
        width: Int,
        height: Int,
        rowStride: Int,
        outHistogram256: IntArray
    ): FloatArray {
        outHistogram256.fill(0)
        val step = 4
        var totalSamples = 0L
        var clippedSamples = 0L
        var gradientEnergy = 0.0

        var y = step
        while (y < height - step) {
            val rowPrev = (y - 1) * rowStride
            val rowCurr = y * rowStride
            val rowNext = (y + 1) * rowStride
            if (rowNext + width > yBytes.size) break

            var x = step
            while (x < width - step) {
                val valCurr = yBytes[rowCurr + x].toInt() and 0xFF
                outHistogram256[valCurr]++
                totalSamples++
                if (valCurr >= 245) clippedSamples++

                val p00 = yBytes[rowPrev + x - 1].toInt() and 0xFF
                val p01 = yBytes[rowPrev + x].toInt() and 0xFF
                val p02 = yBytes[rowPrev + x + 1].toInt() and 0xFF
                val p10 = yBytes[rowCurr + x - 1].toInt() and 0xFF
                val p12 = yBytes[rowCurr + x + 1].toInt() and 0xFF
                val p20 = yBytes[rowNext + x - 1].toInt() and 0xFF
                val p21 = yBytes[rowNext + x].toInt() and 0xFF
                val p22 = yBytes[rowNext + x + 1].toInt() and 0xFF

                val gx = -p00 + p02 - 2 * p10 + 2 * p12 - p20 + p22
                val gy = -p00 - 2 * p01 - p02 + p20 + 2 * p21 + p22
                gradientEnergy += sqrt((gx * gx + gy * gy).toDouble())

                x += step
            }
            y += step
        }

        val clipRatio = if (totalSamples > 0) clippedSamples.toFloat() / totalSamples.toFloat() else 0f
        val sharpness = if (totalSamples > 0) (gradientEnergy / totalSamples.toDouble()).toFloat() else 0f
        return floatArrayOf(clipRatio, sharpness)
    }

    fun nativeMergeMfsrRgb(
        framesRgb: Array<ByteArray>,
        srcWidth: Int,
        srcHeight: Int,
        scaleFactor: Float,
        shiftsXY: FloatArray
    ): ByteArray {
        val dstWidth = max(1, (srcWidth * scaleFactor).roundToInt())
        val dstHeight = max(1, (srcHeight * scaleFactor).roundToInt())
        val dstPixels = dstWidth * dstHeight

        val accumR = FloatArray(dstPixels)
        val accumG = FloatArray(dstPixels)
        val accumB = FloatArray(dstPixels)
        val accumW = FloatArray(dstPixels)
        val refBase = ByteArray(dstPixels * 3)

        val invScale = 1.0f / scaleFactor
        val invTwoSigmaSq = 1.0f / (2.0f * 18.0f * 18.0f)

        for (f in framesRgb.indices) {
            val src = framesRgb[f]
            val dx = if (f * 2 < shiftsXY.size) shiftsXY[f * 2] else 0f
            val dy = if (f * 2 + 1 < shiftsXY.size) shiftsXY[f * 2 + 1] else 0f

            for (y in 0 until dstHeight) {
                val sy = y * invScale + dy
                val iy = floor(sy).toInt()
                val dstRow = y * dstWidth

                for (x in 0 until dstWidth) {
                    val sx = x * invScale + dx
                    val ix = floor(sx).toInt()

                    var rSum = 0f
                    var gSum = 0f
                    var bSum = 0f
                    var wSum = 0f

                    for (ky in -1..2) {
                        val py = (iy + ky).coerceIn(0, srcHeight - 1)
                        val wy = lanczos3(sy - (iy + ky))
                        val rowBase = py * srcWidth * 3
                        for (kx in -1..2) {
                            val px = (ix + kx).coerceIn(0, srcWidth - 1)
                            val w = lanczos3(sx - (ix + kx)) * wy
                            val idx = rowBase + px * 3
                            rSum += (src[idx].toInt() and 0xFF) * w
                            gSum += (src[idx + 1].toInt() and 0xFF) * w
                            bSum += (src[idx + 2].toInt() and 0xFF) * w
                            wSum += w
                        }
                    }

                    if (abs(wSum) < 1e-5f) continue
                    val invW = 1.0f / wSum
                    val r = (rSum * invW).coerceIn(0f, 255f)
                    val g = (gSum * invW).coerceIn(0f, 255f)
                    val b = (bSum * invW).coerceIn(0f, 255f)

                    val outIdx = dstRow + x
                    val frameWeight = if (f == 0) {
                        refBase[outIdx * 3] = clampByte(r)
                        refBase[outIdx * 3 + 1] = clampByte(g)
                        refBase[outIdx * 3 + 2] = clampByte(b)
                        1.25f
                    } else {
                        val rr = refBase[outIdx * 3].toInt() and 0xFF
                        val rg = refBase[outIdx * 3 + 1].toInt() and 0xFF
                        val rb = refBase[outIdx * 3 + 2].toInt() and 0xFF
                        val diff = (abs(r - rr) + abs(g - rg) + abs(b - rb)) / 3.0f
                        exp(-(diff * diff) * invTwoSigmaSq)
                    }

                    accumR[outIdx] += r * frameWeight
                    accumG[outIdx] += g * frameWeight
                    accumB[outIdx] += b * frameWeight
                    accumW[outIdx] += frameWeight
                }
            }
        }

        val outBuf = ByteArray(dstPixels * 3)
        for (i in 0 until dstPixels) {
            val invW = if (accumW[i] > 1e-5f) 1.0f / accumW[i] else 1.0f
            outBuf[i * 3] = clampByte(accumR[i] * invW)
            outBuf[i * 3 + 1] = clampByte(accumG[i] * invW)
            outBuf[i * 3 + 2] = clampByte(accumB[i] * invW)
        }
        return outBuf
    }

    fun nativeEnhanceTileRgb(
        rgbTile: ByteArray,
        width: Int,
        height: Int,
        denoiseStrength: Float,
        deblurStrength: Float,
        hdrStrength: Float,
        microContrast: Float
    ) {
        val count = width * height
        val bufR = FloatArray(count)
        val bufG = FloatArray(count)
        val bufB = FloatArray(count)
        val smoothR = FloatArray(count)
        val smoothG = FloatArray(count)
        val smoothB = FloatArray(count)

        val inv255 = 1.0f / 255.0f
        for (i in 0 until count) {
            bufR[i] = (rgbTile[i * 3].toInt() and 0xFF) * inv255
            bufG[i] = (rgbTile[i * 3 + 1].toInt() and 0xFF) * inv255
            bufB[i] = (rgbTile[i * 3 + 2].toInt() and 0xFF) * inv255
        }

        // Step 1: 3x3 Edge-Preserving Bilateral Denoise
        val denoise = clamp01(denoiseStrength)
        val sigmaColor = 0.04f + 0.12f * denoise
        val invTwoSigmaSq = 1.0f / (2.0f * sigmaColor * sigmaColor)

        for (y in 0 until height) {
            val rowOff = y * width
            for (x in 0 until width) {
                val cIdx = rowOff + x
                val cr = bufR[cIdx]
                val cg = bufG[cIdx]
                val cb = bufB[cIdx]

                if (denoise <= 0.01f) {
                    smoothR[cIdx] = cr
                    smoothG[cIdx] = cg
                    smoothB[cIdx] = cb
                    continue
                }

                var sr = 0f
                var sg = 0f
                var sb = 0f
                var sw = 0f

                for (dy in -1..1) {
                    val ny = (y + dy).coerceIn(0, height - 1)
                    val nRow = ny * width
                    for (dx in -1..1) {
                        val nx = (x + dx).coerceIn(0, width - 1)
                        val nIdx = nRow + nx
                        val dr = bufR[nIdx] - cr
                        val dg = bufG[nIdx] - cg
                        val db = bufB[nIdx] - cb
                        val distSq = dr * dr + dg * dg + db * db
                        val spatialW = if (dx == 0 && dy == 0) 1.0f else if (dx == 0 || dy == 0) 0.65f else 0.45f
                        val w = spatialW * exp(-distSq * invTwoSigmaSq)
                        sr += bufR[nIdx] * w
                        sg += bufG[nIdx] * w
                        sb += bufB[nIdx] * w
                        sw += w
                    }
                }
                val invW = 1.0f / max(sw, 1e-5f)
                smoothR[cIdx] = cr * (1f - denoise) + (sr * invW) * denoise
                smoothG[cIdx] = cg * (1f - denoise) + (sg * invW) * denoise
                smoothB[cIdx] = cb * (1f - denoise) + (sb * invW) * denoise
            }
        }

        // Step 2 & 3: Deconvolution Sharpening + Filmic HDR + Micro-Contrast
        val sharpGain = 1.6f * clamp01(deblurStrength)
        val hdr = clamp01(hdrStrength)
        val contrastGain = 0.45f * clamp01(microContrast)

        for (y in 0 until height) {
            val ym = max(0, y - 1) * width
            val yc = y * width
            val yp = min(height - 1, y + 1) * width

            for (x in 0 until width) {
                val xm = max(0, x - 1)
                val xp = min(width - 1, x + 1)
                val idx = yc + x

                val avgR = 0.25f * (smoothR[yc + xm] + smoothR[yc + xp] + smoothR[ym + x] + smoothR[yp + x])
                val avgG = 0.25f * (smoothG[yc + xm] + smoothG[yc + xp] + smoothG[ym + x] + smoothG[yp + x])
                val avgB = 0.25f * (smoothB[yc + xm] + smoothB[yc + xp] + smoothB[ym + x] + smoothB[yp + x])

                var r = smoothR[idx] + (smoothR[idx] - avgR) * sharpGain
                var g = smoothG[idx] + (smoothG[idx] - avgG) * sharpGain
                var b = smoothB[idx] + (smoothB[idx] - avgB) * sharpGain

                if (hdr > 0.01f) {
                    val lum = max(1e-4f, 0.2126f * r + 0.7152f * g + 0.0722f * b)
                    val liftedLum = lum.pow(1.0f - 0.18f * hdr)
                    val mappedLum = acesFilmic(liftedLum * (1.0f + 0.35f * hdr))
                    val scale = mappedLum / lum
                    r = r * (1f - hdr) + (r * scale) * hdr
                    g = g * (1f - hdr) + (g * scale) * hdr
                    b = b * (1f - hdr) + (b * scale) * hdr
                }

                if (contrastGain > 0.01f) {
                    val cr = clamp01(r)
                    val cg = clamp01(g)
                    val cb = clamp01(b)
                    r = cr * (1f - contrastGain) + (cr * cr * (3f - 2f * cr)) * contrastGain
                    g = cg * (1f - contrastGain) + (cg * cg * (3f - 2f * cg)) * contrastGain
                    b = cb * (1f - contrastGain) + (cb * cb * (3f - 2f * cb)) * contrastGain
                }

                rgbTile[idx * 3] = clampByte(clamp01(r) * 255f)
                rgbTile[idx * 3 + 1] = clampByte(clamp01(g) * 255f)
                rgbTile[idx * 3 + 2] = clampByte(clamp01(b) * 255f)
            }
        }
    }

    fun nativeBlendTileHann(
        srcTileRgb: ByteArray,
        tileW: Int,
        tileH: Int,
        dstAccumRgb: FloatArray,
        dstWeight: FloatArray,
        dstW: Int,
        dstH: Int,
        offsetX: Int,
        offsetY: Int,
        featherPx: Int
    ) {
        val pi = Math.PI.toFloat()
        val fPx = max(1, featherPx).toFloat()

        for (y in 0 until tileH) {
            val dy = offsetY + y
            if (dy < 0 || dy >= dstH) continue

            val wy = when {
                y < featherPx -> 0.5f * (1.0f - cos(pi * (y + 1) / fPx))
                tileH - 1 - y < featherPx -> 0.5f * (1.0f - cos(pi * (tileH - y) / fPx))
                else -> 1.0f
            }

            val srcRow = y * tileW
            val dstRow = dy * dstW

            for (x in 0 until tileW) {
                val dx = offsetX + x
                if (dx < 0 || dx >= dstW) continue

                val wx = when {
                    x < featherPx -> 0.5f * (1.0f - cos(pi * (x + 1) / fPx))
                    tileW - 1 - x < featherPx -> 0.5f * (1.0f - cos(pi * (tileW - x) / fPx))
                    else -> 1.0f
                }

                val w = max(1e-4f, wx * wy)
                val sIdx = (srcRow + x) * 3
                val dPix = dstRow + dx

                dstAccumRgb[dPix * 3] += (srcTileRgb[sIdx].toInt() and 0xFF) * w
                dstAccumRgb[dPix * 3 + 1] += (srcTileRgb[sIdx + 1].toInt() and 0xFF) * w
                dstAccumRgb[dPix * 3 + 2] += (srcTileRgb[sIdx + 2].toInt() and 0xFF) * w
                dstWeight[dPix] += w
            }
        }
    }
}
