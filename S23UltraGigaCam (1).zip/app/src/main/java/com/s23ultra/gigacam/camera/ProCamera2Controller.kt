package com.s23ultra.gigacam.camera

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.*
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.RggbChannelVector
import android.hardware.camera2.params.SessionConfiguration
import android.media.Image
import android.media.ImageReader
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.Size
import android.view.Surface
import com.s23ultra.gigacam.domain.ProCameraSettings
import com.s23ultra.gigacam.domain.S23UltraLens
import com.s23ultra.gigacam.processing.NativeGigaEngine
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.ln
import kotlin.math.pow

data class CapturedFrame(
    val jpegBytes: ByteArray? = null,
    val rawFile: File? = null,
    val width: Int,
    val height: Int,
    val exposureNs: Long,
    val iso: Int
)

/**
 * Full Camera2 API Pro Engine optimized for Samsung Galaxy S23 Ultra:
 * - Physical multi-lens switching (0.6x, 1x 200MP/50MP, 3x, 10x)
 * - Manual ISO, Shutter Speed (1/12000s - 30s), Manual Focus (diopters), Manual Kelvin WB
 * - High-Res Maximum Resolution sensor pixel mode (Android 12+)
 * - RAW DNG 12-bit capture via DngCreator
 * - Rapid ZSL burst for Multi-Frame Super-Resolution (MFSR)
 * - Exposure Bracketing (HDR+) & Focus Bracketing (Focus Stacking)
 * - Live YUV Analyzer for Histogram, Zebra Clipping, and Focus Peaking
 */
class ProCamera2Controller(
    private val context: Context,
    private val onLiveAnalysis: (histogram: IntArray, zebraRatio: Float, sharpness: Float) -> Unit
) {
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val lensMapper = S23UltraLensMapper(cameraManager)
    private val cameraExecutor = Executors.newSingleThreadExecutor()

    private val backgroundThread = HandlerThread("S23U-Camera2").apply { start() }
    private val backgroundHandler = Handler(backgroundThread.looper)

    val availableLenses: Map<S23UltraLens, PhysicalLensProfile> = lensMapper.discoverRearLenses()

    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var activeProfile: PhysicalLensProfile? = null
    private var previewSurface: Surface? = null
    private var jpegReader: ImageReader? = null
    private var rawReader: ImageReader? = null
    private var analysisReader: ImageReader? = null

    private var currentSettings: ProCameraSettings = ProCameraSettings()
    private val histogramBuffer = IntArray(256)
    private var lastAnalysisTimeMs = 0L

    @SuppressLint("MissingPermission")
    suspend fun openLens(lens: S23UltraLens, surface: Surface, settings: ProCameraSettings) {
        closeCamera()
        currentSettings = settings
        previewSurface = surface

        val profile = availableLenses[lens]
            ?: availableLenses[S23UltraLens.WIDE_1X_200MP]
            ?: throw IllegalStateException("No rear camera available")
        activeProfile = profile

        val device = suspendCancellableCoroutine<CameraDevice> { cont ->
            cameraManager.openCamera(profile.cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(cam: CameraDevice) {
                    if (cont.isActive) cont.resume(cam)
                }

                override fun onDisconnected(cam: CameraDevice) {
                    cam.close()
                }

                override fun onError(cam: CameraDevice, error: Int) {
                    cam.close()
                    if (cont.isActive) cont.resumeWithException(RuntimeException("Camera2 open error=$error"))
                }
            }, backgroundHandler)
        }
        cameraDevice = device
        createCaptureSession(device, profile, surface)
    }

    private suspend fun createCaptureSession(
        device: CameraDevice,
        profile: PhysicalLensProfile,
        preview: Surface
    ) {
        val captureSize = profile.maxUltraHighResJpegSize ?: profile.maxStandardJpegSize
        jpegReader = ImageReader.newInstance(captureSize.width, captureSize.height, ImageFormat.JPEG, 6)

        if (profile.supportsRaw && profile.maxRawSize != null && currentSettings.captureRawDng) {
            rawReader = ImageReader.newInstance(
                profile.maxRawSize.width,
                profile.maxRawSize.height,
                ImageFormat.RAW_SENSOR,
                3
            )
        }

        // Low-res YUV stream for real-time 60fps histogram, focus peaking, and zebra telemetry
        val analysisSize = Size(640, 480)
        analysisReader = ImageReader.newInstance(
            analysisSize.width,
            analysisSize.height,
            ImageFormat.YUV_420_888,
            2
        ).apply {
            setOnImageAvailableListener({ reader ->
                val img = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    val now = System.currentTimeMillis()
                    if (now - lastAnalysisTimeMs >= 66L) { // ~15Hz UI telemetry
                        lastAnalysisTimeMs = now
                        analyzeYuvFrame(img)
                    }
                } finally {
                    img.close()
                }
            }, backgroundHandler)
        }

        val configs = mutableListOf<OutputConfiguration>()
        fun addConfig(s: Surface) {
            val oc = OutputConfiguration(s)
            profile.physicalCameraId?.let { physId ->
                oc.setPhysicalCameraId(physId)
            }
            configs.add(oc)
        }

        addConfig(preview)
        addConfig(jpegReader!!.surface)
        addConfig(analysisReader!!.surface)
        rawReader?.surface?.let { addConfig(it) }

        val session = suspendCancellableCoroutine<CameraCaptureSession> { cont ->
            val callback = object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    if (cont.isActive) cont.resume(s)
                }

                override fun onConfigureFailed(s: CameraCaptureSession) {
                    if (cont.isActive) cont.resumeWithException(RuntimeException("Camera2 session config failed"))
                }
            }
            val sessionConfig = SessionConfiguration(
                SessionConfiguration.SESSION_REGULAR,
                configs,
                cameraExecutor,
                callback
            )
            device.createCaptureSession(sessionConfig)
        }

        captureSession = session
        updatePreviewSettings(currentSettings)
    }

    fun updatePreviewSettings(settings: ProCameraSettings) {
        currentSettings = settings
        val device = cameraDevice ?: return
        val session = captureSession ?: return
        val preview = previewSurface ?: return

        val builder = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
            addTarget(preview)
            analysisReader?.surface?.let { addTarget(it) }
            applyProParameters(this, settings, isStillCapture = false)
        }
        runCatching {
            session.setRepeatingRequest(builder.build(), null, backgroundHandler)
        }
    }

    /**
     * Captures a high-resolution single frame (optionally with 12-bit RAW DNG alongside JPEG).
     */
    suspend fun captureSingleFrame(
        settings: ProCameraSettings,
        evOffset: Int = 0,
        focusOverrideDiopters: Float? = null,
        rawOutputDir: File? = null
    ): CapturedFrame {
        val device = cameraDevice ?: throw IllegalStateException("Camera not open")
        val session = captureSession ?: throw IllegalStateException("Session not ready")
        val reader = jpegReader ?: throw IllegalStateException("JPEG reader not ready")
        val profile = activeProfile ?: throw IllegalStateException("No active lens profile")

        val jpegDeferred = CompletableDeferred<ByteArray>()
        val resultDeferred = CompletableDeferred<TotalCaptureResult>()
        val rawImageDeferred = if (rawReader != null && settings.captureRawDng && rawOutputDir != null) {
            CompletableDeferred<Image>()
        } else null

        reader.setOnImageAvailableListener({ r ->
            val img = r.acquireNextImage() ?: return@setOnImageAvailableListener
            try {
                val buf = img.planes[0].buffer
                val bytes = ByteArray(buf.remaining())
                buf.get(bytes)
                jpegDeferred.complete(bytes)
            } finally {
                img.close()
            }
        }, backgroundHandler)

        rawReader?.setOnImageAvailableListener({ r ->
            val img = r.acquireNextImage() ?: return@setOnImageAvailableListener
            if (rawImageDeferred != null && !rawImageDeferred.isCompleted) {
                rawImageDeferred.complete(img)
            } else {
                img.close()
            }
        }, backgroundHandler)

        val builder = device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
            addTarget(reader.surface)
            if (rawImageDeferred != null) {
                rawReader?.surface?.let { addTarget(it) }
            }
            applyProParameters(
                builder = this,
                settings = settings.copy(evCompensation = settings.evCompensation + evOffset),
                isStillCapture = true,
                focusOverride = focusOverrideDiopters
            )
            // Request maximum sensor pixel mode on Android 12+ (enables 50MP/200MP high-res path)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && profile.maxUltraHighResJpegSize != null) {
                set(
                    CaptureRequest.SENSOR_PIXEL_MODE,
                    CaptureRequest.SENSOR_PIXEL_MODE_MAXIMUM_RESOLUTION
                )
            }
        }

        session.capture(builder.build(), object : CameraCaptureSession.CaptureCallback() {
            override fun onCaptureCompleted(
                s: CameraCaptureSession,
                req: CaptureRequest,
                result: TotalCaptureResult
            ) {
                resultDeferred.complete(result)
            }

            override fun onCaptureFailed(
                s: CameraCaptureSession,
                req: CaptureRequest,
                failure: CaptureFailure
            ) {
                val ex = RuntimeException("Capture failed reason=${failure.reason}")
                jpegDeferred.completeExceptionally(ex)
                resultDeferred.completeExceptionally(ex)
            }
        }, backgroundHandler)

        val jpegBytes = jpegDeferred.await()
        val captureResult = resultDeferred.await()

        var savedRawFile: File? = null
        if (rawImageDeferred != null && rawOutputDir != null) {
            val rawImg = rawImageDeferred.await()
            try {
                val chars = cameraManager.getCameraCharacteristics(profile.cameraId)
                val outFile = File(rawOutputDir, "RAW_${System.currentTimeMillis()}.dng")
                DngCreator(chars, captureResult).use { dng ->
                    FileOutputStream(outFile).use { fos ->
                        dng.writeImage(fos, rawImg)
                    }
                }
                savedRawFile = outFile
            } finally {
                rawImg.close()
            }
        }

        return CapturedFrame(
            jpegBytes = jpegBytes,
            rawFile = savedRawFile,
            width = reader.width,
            height = reader.height,
            exposureNs = captureResult.get(CaptureResult.SENSOR_EXPOSURE_TIME) ?: settings.shutterSpeedNs,
            iso = captureResult.get(CaptureResult.SENSOR_SENSITIVITY) ?: settings.iso
        )
    }

    /**
     * Rapid multi-frame burst capture for MFSR (sub-pixel hand-tremor super-resolution) & Astro stacking.
     */
    suspend fun captureBurst(
        frameCount: Int,
        settings: ProCameraSettings,
        onFrameCaptured: (index: Int, total: Int) -> Unit = { _, _ -> }
    ): List<CapturedFrame> {
        val frames = ArrayList<CapturedFrame>(frameCount)
        for (i in 0 until frameCount) {
            frames.add(captureSingleFrame(settings))
            onFrameCaptured(i + 1, frameCount)
        }
        return frames
    }

    /**
     * Auto Exposure Bracketing (AEB) for Pro HDR Fusion (e.g. -2EV, 0EV, +2EV).
     */
    suspend fun captureExposureBracket(
        settings: ProCameraSettings,
        onStep: (Int, Int) -> Unit = { _, _ -> }
    ): List<CapturedFrame> {
        val count = settings.hdrBracketFrames.coerceIn(3, 7)
        val half = count / 2
        val step = settings.hdrBracketEvStep.toInt().coerceAtLeast(1)
        val frames = mutableListOf<CapturedFrame>()
        for (i in -half..half) {
            frames.add(captureSingleFrame(settings, evOffset = i * step))
            onStep(frames.size, count)
        }
        return frames
    }

    /**
     * Focus Bracketing Sweep from near macro to infinity for Focus Stacking.
     */
    suspend fun captureFocusStack(
        settings: ProCameraSettings,
        onStep: (Int, Int) -> Unit = { _, _ -> }
    ): List<CapturedFrame> {
        val profile = activeProfile ?: return emptyList()
        val steps = settings.focusStackSteps.coerceIn(3, 15)
        val maxD = profile.minFocusDistance.coerceAtMost(8.0f)
        val frames = mutableListOf<CapturedFrame>()
        for (i in 0 until steps) {
            val diopter = maxD * (1.0f - (i.toFloat() / (steps - 1).coerceAtLeast(1)))
            frames.add(
                captureSingleFrame(
                    settings = settings.copy(manualFocus = true),
                    focusOverrideDiopters = diopter
                )
            )
            onStep(i + 1, steps)
        }
        return frames
    }

    private fun applyProParameters(
        builder: CaptureRequest.Builder,
        settings: ProCameraSettings,
        isStillCapture: Boolean,
        focusOverride: Float? = null
    ) {
        val profile = activeProfile

        // High-quality processing flags
        builder.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
        builder.set(
            CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
            if (settings.oisEnabled) CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON
            else CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_OFF
        )
        builder.set(CaptureRequest.JPEG_QUALITY, 100.toByte())
        builder.set(
            CaptureRequest.EDGE_MODE,
            if (isStillCapture) CaptureRequest.EDGE_MODE_HIGH_QUALITY else CaptureRequest.EDGE_MODE_FAST
        )
        builder.set(
            CaptureRequest.NOISE_REDUCTION_MODE,
            if (isStillCapture) CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY
            else CaptureRequest.NOISE_REDUCTION_MODE_FAST
        )
        builder.set(
            CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE,
            CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY
        )

        // Manual vs Auto Exposure
        if (settings.manualExposure && profile != null) {
            builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            val clampedIso = settings.iso.coerceIn(profile.isoRange.lower, profile.isoRange.upper)
            val clampedExp = settings.shutterSpeedNs.coerceIn(
                profile.exposureTimeRangeNs.lower,
                profile.exposureTimeRangeNs.upper
            )
            builder.set(CaptureRequest.SENSOR_SENSITIVITY, clampedIso)
            builder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, clampedExp)
        } else {
            builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
            builder.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, settings.evCompensation)
            builder.set(CaptureRequest.CONTROL_AE_LOCK, settings.aeAfLocked)
        }

        // Manual vs Continuous Auto Focus
        val targetFocus = focusOverride ?: if (settings.manualFocus) settings.focusDistanceDiopters else null
        if (targetFocus != null) {
            builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
            builder.set(CaptureRequest.LENS_FOCUS_DISTANCE, targetFocus.coerceAtLeast(0.0f))
        } else {
            builder.set(
                CaptureRequest.CONTROL_AF_MODE,
                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
            )
        }

        // Manual Kelvin White Balance via Tanner Helland Planckian locus RGGB gain approximation
        if (settings.manualWhiteBalance) {
            builder.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_OFF)
            builder.set(
                CaptureRequest.COLOR_CORRECTION_MODE,
                CaptureRequest.COLOR_CORRECTION_MODE_TRANSFORM_MATRIX
            )
            builder.set(
                CaptureRequest.COLOR_CORRECTION_GAINS,
                kelvinToRggbGains(settings.whiteBalanceKelvin)
            )
        } else {
            builder.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
        }
    }

    private fun kelvinToRggbGains(kelvin: Int): RggbChannelVector {
        val temp = kelvin.coerceIn(2000, 10000) / 100.0
        val r = if (temp <= 66) 255.0 else (329.698727446 * (temp - 60).pow(-0.1332047592)).coerceIn(0.0, 255.0)
        val g = if (temp <= 66) (99.4708025861 * ln(temp) - 161.1195681661).coerceIn(0.0, 255.0)
        else (288.1221695283 * (temp - 60).pow(-0.0755148492)).coerceIn(0.0, 255.0)
        val b = when {
            temp >= 66 -> 255.0
            temp <= 19 -> 0.0
            else -> (138.5177312231 * ln(temp - 10) - 305.0447927307).coerceIn(0.0, 255.0)
        }
        val normG = (g / 255.0).coerceAtLeast(0.2)
        val rGain = ((r / 255.0) / normG * 1.4).toFloat().coerceIn(0.6f, 3.5f)
        val bGain = ((b / 255.0) / normG * 1.4).toFloat().coerceIn(0.6f, 3.5f)
        return RggbChannelVector(rGain, 1.0f, 1.0f, bGain)
    }

    private fun analyzeYuvFrame(image: Image) {
        val yPlane = image.planes[0]
        val buf = yPlane.buffer
        val bytes = ByteArray(buf.remaining())
        buf.get(bytes)
        val metrics = NativeGigaEngine.nativeAnalyzeYPlane(
            bytes,
            image.width,
            image.height,
            yPlane.rowStride,
            histogramBuffer
        )
        onLiveAnalysis(histogramBuffer.copyOf(), metrics[0], metrics[1])
    }

    fun closeCamera() {
        runCatching { captureSession?.close() }
        runCatching { cameraDevice?.close() }
        runCatching { jpegReader?.close() }
        runCatching { rawReader?.close() }
        runCatching { analysisReader?.close() }
        captureSession = null
        cameraDevice = null
        jpegReader = null
        rawReader = null
        analysisReader = null
    }

    fun release() {
        closeCamera()
        backgroundThread.quitSafely()
        cameraExecutor.shutdown()
    }
}
