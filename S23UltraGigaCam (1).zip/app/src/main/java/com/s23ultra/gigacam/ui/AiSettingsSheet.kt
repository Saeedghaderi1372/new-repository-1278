package com.s23ultra.gigacam.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.s23ultra.gigacam.domain.AiEnhanceConfig
import com.s23ultra.gigacam.domain.AiPreset

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiSettingsSheet(
    aiConfig: AiEnhanceConfig,
    isOnnxModelLoaded: Boolean,
    onUpdate: ((AiEnhanceConfig) -> AiEnhanceConfig) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF101318),
        contentColor = Color.White
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "موتور هوشمند AI Ultra-Enhance",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF38BDF8)
                        )
                        Text(
                            text = if (isOnnxModelLoaded) "شتاب‌دهنده NPU/ONNX فعال (Real-ESRGAN)"
                            else "موتور C++ بومی فعال (آماده اتصال به مدل ONNX)",
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                    Switch(
                        checked = aiConfig.enabled,
                        onCheckedChange = { enabled -> onUpdate { it.copy(enabled = enabled) } }
                    )
                }
            }

            item {
                Text("انتخاب پروفایل هوش مصنوعی:", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }

            items(AiPreset.entries) { preset ->
                val selected = aiConfig.preset == preset
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (selected) Color(0xFF1E293B) else Color(0xFF161B22))
                        .border(
                            width = if (selected) 1.5.dp else 1.dp,
                            color = if (selected) Color(0xFF38BDF8) else Color(0xFF2B3442),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .clickable { onUpdate { it.copy(enabled = preset != AiPreset.OFF, preset = preset) } }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = preset.labelFa,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = if (selected) Color(0xFF38BDF8) else Color.White
                        )
                        Text(
                            text = preset.descFa,
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                    if (selected) {
                        Text("فعال", color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            item {
                HorizontalDivider(color = Color(0xFF263040))
                AiSliderRow("حذف نویز هوشمند (Denoise)", aiConfig.denoiseStrength) { v ->
                    onUpdate { it.copy(denoiseStrength = v) }
                }
                AiSliderRow("رفع تاری و شارپنس اپتیکال (Deblur)", aiConfig.deblurStrength) { v ->
                    onUpdate { it.copy(deblurStrength = v) }
                }
                AiSliderRow("گستره دینامیکی HDR Filmic", aiConfig.hdrStrength) { v ->
                    onUpdate { it.copy(hdrStrength = v) }
                }
                AiSliderRow("میکرو-کنتراست و بافت جزئیات", aiConfig.microContrast) { v ->
                    onUpdate { it.copy(microContrast = v) }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("شتاب‌دهی سخت‌افزاری Snapdragon Hexagon NPU", fontSize = 13.sp)
                    Switch(
                        checked = aiConfig.useHexagonNpu,
                        onCheckedChange = { npu -> onUpdate { it.copy(useHexagonNpu = npu) } }
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun AiSliderRow(label: String, value: Float, onChange: (Float) -> Unit) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 13.sp, color = Color(0xFFE2E8F0))
            Text("${(value * 100).toInt()}%", fontSize = 12.sp, color = Color(0xFFF59E0B))
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = 0f..1f,
            colors = SliderDefaults.colors(
                thumbColor = Color(0xFF38BDF8),
                activeTrackColor = Color(0xFF38BDF8)
            )
        )
    }
}
