package com.s23ultra.gigacam.ui

import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import kotlin.math.ceil
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.roundToInt

private data class DziMeta(
    val fullWidth: Int,
    val fullHeight: Int,
    val tileSize: Int,
    val tilesDir: File,
    val maxLevel: Int
)

private fun parseDziManifest(dziPath: String?): DziMeta? {
    if (dziPath == null) return null
    val file = File(dziPath)
    if (!file.exists()) return null
    val xml = runCatching { file.readText() }.getOrNull() ?: return null
    val w = Regex("""Width="(\d+)"""").find(xml)?.groupValues?.get(1)?.toIntOrNull() ?: return null
    val h = Regex("""Height="(\d+)"""").find(xml)?.groupValues?.get(1)?.toIntOrNull() ?: return null
    val ts = Regex("""TileSize="(\d+)"""").find(xml)?.groupValues?.get(1)?.toIntOrNull() ?: 512
    val baseName = file.nameWithoutExtension
    val tilesDir = File(file.parentFile, "${baseName}_files")
    val maxLevel = ceil(ln(max(w, h).toDouble()) / ln(2.0)).toInt()
    return DziMeta(w, h, ts, tilesDir, maxLevel)
}

/**
 * Out-of-Core Gigapixel Deep-Zoom Viewer:
 * Renders the base preview immediately and dynamically loads visible Deep Zoom (.dzi) tiles
 * from disk into a bounded LRU cache as the user pinches/zooms up to 250x on 800MP–5000MP images.
 */
@Composable
fun GigaViewerScreen(
    previewPath: String?,
    dziPath: String?,
    bigTiffPath: String?,
    resolutionLabel: String,
    onBack: () -> Unit
) {
    var zoom by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    val dziMeta = remember(dziPath) { parseDziManifest(dziPath) }
    val tileCache = remember(dziPath) { LruCache<String, ImageBitmap>(48) }

    val previewImage = remember(previewPath) {
        previewPath?.let { path ->
            val f = File(path)
            if (f.exists()) BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap() else null
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, gestureZoom, _ ->
                    zoom = (zoom * gestureZoom).coerceIn(1f, 250f)
                    offset = Offset(offset.x + pan.x, offset.y + pan.y)
                }
            }
    ) {
        if (previewImage != null) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val aspect = previewImage.width.toFloat() / previewImage.height.toFloat()
                val drawW = size.width
                val drawH = drawW / aspect
                val baseTop = (size.height - drawH) / 2f

                withTransform({
                    translate(left = offset.x, top = offset.y)
                    scale(scaleX = zoom, scaleY = zoom, pivot = center)
                }) {
                    // Base overview layer
                    drawImage(
                        image = previewImage,
                        dstOffset = IntOffset(0, baseTop.roundToInt()),
                        dstSize = IntSize(drawW.roundToInt(), drawH.roundToInt())
                    )

                    // On-demand Deep Zoom high-resolution tiles when zoomed in (> 2x)
                    if (dziMeta != null && zoom > 2.0f) {
                        val desiredWidthPx = drawW * zoom
                        val targetLevel = ceil(ln(desiredWidthPx.toDouble()) / ln(2.0)).toInt()
                            .coerceIn(8, dziMeta.maxLevel)
                        val levelDir = File(dziMeta.tilesDir, "$targetLevel")
                        if (levelDir.exists()) {
                            val scaleDown = (1 shl (dziMeta.maxLevel - targetLevel)).toFloat()
                            val levelW = max(1f, dziMeta.fullWidth / scaleDown)
                            val levelH = max(1f, dziMeta.fullHeight / scaleDown)
                            val cols = ceil(levelW / dziMeta.tileSize).toInt()
                            val rows = ceil(levelH / dziMeta.tileSize).toInt()
                            val tileDrawW = drawW * (dziMeta.tileSize / levelW)
                            val tileDrawH = drawH * (dziMeta.tileSize / levelH)

                            for (r in 0 until rows) {
                                for (c in 0 until cols) {
                                    val key = "${targetLevel}_${c}_${r}"
                                    var tileImg = tileCache.get(key)
                                    if (tileImg == null) {
                                        val tileFile = File(levelDir, "${c}_${r}.jpg")
                                        if (tileFile.exists()) {
                                            BitmapFactory.decodeFile(tileFile.absolutePath)
                                                ?.asImageBitmap()
                                                ?.let { bmp ->
                                                    tileCache.put(key, bmp)
                                                    tileImg = bmp
                                                }
                                        }
                                    }
                                    tileImg?.let { img ->
                                        val tx = c * tileDrawW
                                        val ty = baseTop + r * tileDrawH
                                        val tw = (tileDrawW * (img.width.toFloat() / dziMeta.tileSize)).roundToInt().coerceAtLeast(1)
                                        val th = (tileDrawH * (img.height.toFloat() / dziMeta.tileSize)).roundToInt().coerceAtLeast(1)
                                        drawImage(
                                            image = img,
                                            dstOffset = IntOffset(tx.roundToInt(), ty.roundToInt()),
                                            dstSize = IntSize(tw, th)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            Text(
                text = "هنوز عکسی برای نمایش گیگاپیکسلی ثبت نشده است",
                color = Color.White,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        // Top HUD
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(16.dp)
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = onBack,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC1E293B))
            ) {
                Text("بازگشت به دوربین", color = Color.White)
            }

            Column(
                horizontalAlignment = Alignment.End,
                modifier = Modifier
                    .background(Color(0xBB0F172A), RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "GigaViewer • $resolutionLabel",
                    color = Color(0xFFF59E0B),
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                val dimText = dziMeta?.let { "${it.fullWidth}×${it.fullHeight} px" } ?: ""
                Text(
                    text = "بزرگ‌نمایی: %.1fx  $dimText".format(zoom),
                    color = Color(0xFF38BDF8),
                    fontSize = 11.sp
                )
            }
        }

        // Bottom file metadata bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .background(Color(0xCC090D12))
                .padding(14.dp)
        ) {
            Text("مسیر فایل‌های خروجی:", color = Color(0xFF94A3B8), fontSize = 11.sp)
            bigTiffPath?.let {
                Text("BigTIFF 64-bit: $it", color = Color(0xFF34D399), fontSize = 11.sp, maxLines = 1)
            }
            dziPath?.let {
                Text("DeepZoom Pyramid: $it", color = Color(0xFF38BDF8), fontSize = 11.sp, maxLines = 1)
            }
            previewPath?.let {
                Text("Gallery Preview: $it", color = Color.White, fontSize = 11.sp, maxLines = 1)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { zoom = 1f; offset = Offset.Zero }) {
                    Text("بازنشانی 1x", color = Color.White, fontSize = 12.sp)
                }
                OutlinedButton(onClick = { zoom = 10f }) {
                    Text("زوم 10x", color = Color(0xFFF59E0B), fontSize = 12.sp)
                }
                OutlinedButton(onClick = { zoom = 50f }) {
                    Text("زوم 50x", color = Color(0xFF38BDF8), fontSize = 12.sp)
                }
            }
        }
    }
}
