package com.s23ultra.gigacam.camera

import android.graphics.ImageFormat
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.util.Range
import android.util.Size
import com.s23ultra.gigacam.domain.S23UltraLens
import kotlin.math.abs

data class PhysicalLensProfile(
    val lens: S23UltraLens,
    val cameraId: String,
    val physicalCameraId: String?,
    val focalLengthMm: Float,
    val maxStandardJpegSize: Size,
    val maxUltraHighResJpegSize: Size?,
    val maxRawSize: Size?,
    val supportsRaw: Boolean,
    val isoRange: Range<Int>,
    val exposureTimeRangeNs: Range<Long>,
    val minFocusDistance: Float
)

/**
 * Discovers and maps all 4 rear cameras on Samsung Galaxy S23 Ultra (SM-S918x):
 *  - Ultra-Wide 0.6x (~2.2mm physical focal length)
 *  - Wide Main 1x 200MP ISOCELL HP2 (~6.3mm physical focal length)
 *  - Telephoto 3x (~7.9mm physical focal length)
 *  - Periscope 10x (~27.2mm physical focal length)
 * Also inspects Android 12+ MAXIMUM_RESOLUTION stream maps for 50MP/200MP high-res capture.
 */
class S23UltraLensMapper(private val cameraManager: CameraManager) {

    fun discoverRearLenses(): Map<S23UltraLens, PhysicalLensProfile> {
        val discovered = mutableMapOf<S23UltraLens, PhysicalLensProfile>()
        val candidates = mutableListOf<Triple<String, String?, CameraCharacteristics>>()

        for (id in cameraManager.cameraIdList) {
            val chars = cameraManager.getCameraCharacteristics(id)
            val facing = chars.get(CameraCharacteristics.LENS_FACING)
            if (facing != CameraCharacteristics.LENS_FACING_BACK) continue

            candidates.add(Triple(id, null, chars))

            // Inspect physical sub-cameras inside logical multi-camera IDs
            for (physId in chars.physicalCameraIds) {
                runCatching {
                    val pChars = cameraManager.getCameraCharacteristics(physId)
                    candidates.add(Triple(id, physId, pChars))
                }
            }
        }

        // Compute 35mm-equivalent focal lengths to match each S23 Ultra lens reliably
        val sortedByEqFocal = candidates.mapNotNull { (camId, physId, chars) ->
            val focal = chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()
                ?: return@mapNotNull null
            val sensorSize = chars.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
                ?: return@mapNotNull null
            val eq35mm = (focal * 36.0f) / sensorSize.width.coerceAtLeast(1.0f)
            Quad(camId, physId, chars, eq35mm)
        }.distinctBy { "${it.camId}:${it.physId}" }

        for (targetLens in S23UltraLens.entries) {
            val best = sortedByEqFocal.minByOrNull { abs(it.eq35mm - targetLens.focalLengthEqMm) }
            if (best != null && abs(best.eq35mm - targetLens.focalLengthEqMm) < targetLens.focalLengthEqMm * 0.65f) {
                discovered[targetLens] = buildProfile(targetLens, best.camId, best.physId, best.chars)
            }
        }

        // Always guarantee at least WIDE_1X_200MP maps to primary back camera "0"
        if (S23UltraLens.WIDE_1X_200MP !in discovered && sortedByEqFocal.isNotEmpty()) {
            val primary = sortedByEqFocal.first()
            discovered[S23UltraLens.WIDE_1X_200MP] = buildProfile(
                S23UltraLens.WIDE_1X_200MP, primary.camId, primary.physId, primary.chars
            )
        }

        return discovered
    }

    private fun buildProfile(
        lens: S23UltraLens,
        cameraId: String,
        physicalId: String?,
        chars: CameraCharacteristics
    ): PhysicalLensProfile {
        val focal = chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: 6.3f
        val stdMap = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        val stdJpegSizes = stdMap?.getOutputSizes(ImageFormat.JPEG).orEmpty()
        val maxStd = stdJpegSizes.maxByOrNull { it.width.toLong() * it.height.toLong() } ?: Size(4000, 3000)

        // Query Android 12+ Maximum Resolution Sensor Pixel Mode (50MP / 200MP on HP2)
        val maxHighRes = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val maxMap = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP_MAXIMUM_RESOLUTION)
            val ultraSizes = maxMap?.getOutputSizes(ImageFormat.JPEG).orEmpty() +
                    (stdMap?.getHighResolutionOutputSizes(ImageFormat.JPEG).orEmpty())
            ultraSizes.maxByOrNull { it.width.toLong() * it.height.toLong() }
        } else {
            stdMap?.getHighResolutionOutputSizes(ImageFormat.JPEG)
                ?.maxByOrNull { it.width.toLong() * it.height.toLong() }
        }

        val capabilities = chars.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES).orEmpty()
        val supportsRaw = capabilities.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW)
        val maxRaw = if (supportsRaw) {
            stdMap?.getOutputSizes(ImageFormat.RAW_SENSOR)
                ?.maxByOrNull { it.width.toLong() * it.height.toLong() }
        } else null

        val isoRange = chars.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: Range(50, 3200)
        val expRange = chars.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
            ?: Range(83_000L, 30_000_000_000L) // 1/12000s to 30s
        val minFocus = chars.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 10.0f

        return PhysicalLensProfile(
            lens = lens,
            cameraId = cameraId,
            physicalCameraId = physicalId,
            focalLengthMm = focal,
            maxStandardJpegSize = maxStd,
            maxUltraHighResJpegSize = maxHighRes,
            maxRawSize = maxRaw,
            supportsRaw = supportsRaw,
            isoRange = isoRange,
            exposureTimeRangeNs = expRange,
            minFocusDistance = minFocus
        )
    }

    private data class Quad(
        val camId: String,
        val physId: String?,
        val chars: CameraCharacteristics,
        val eq35mm: Float
    )
}
