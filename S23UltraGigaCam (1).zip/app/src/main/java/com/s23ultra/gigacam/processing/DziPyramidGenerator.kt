package com.s23ultra.gigacam.processing

import android.graphics.Bitmap
import java.io.File
import java.io.FileOutputStream
import kotlin.math.ceil
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/**
 * Generates a Deep Zoom Image (.dzi) multi-resolution JPEG tile pyramid directly from streaming
 * out-of-core tiles so the built-in GigaViewer can pan & pinch-zoom smoothly to 250x magnification
 * on 1000MP–5000MP photos without loading the full gigapixel bitmap into Android RAM.
 */
class DziPyramidGenerator(
    private val outputDir: File,
    private val baseName: String,
    val fullWidth: Int,
    val fullHeight: Int,
    val tileSize: Int = 512,
    val jpegQuality: Int = 94
) {
    val maxLevel: Int = ceil(ln(max(fullWidth, fullHeight).toDouble()) / ln(2.0)).toInt()
    val tilesRootDir: File = File(outputDir, "${baseName}_files").apply { mkdirs() }
    val dziManifestFile: File = File(outputDir, "$baseName.dzi")

    init {
        writeManifest()
    }

    private fun writeManifest() {
        val xml = """
            <?xml version="1.0" encoding="UTF-8"?>
            <Image xmlns="http://schemas.microsoft.com/deepzoom/2008"
                   Format="jpg"
                   Overlap="0"
                   TileSize="$tileSize">
                <Size Width="$fullWidth" Height="$fullHeight" />
            </Image>
        """.trimIndent()
        dziManifestFile.writeText(xml)
    }

    /**
     * Writes a single highest-resolution tile at (col, row) for level = maxLevel.
     */
    fun writeFullResTile(col: Int, row: Int, tileBitmap: Bitmap) {
        val levelDir = File(tilesRootDir, "$maxLevel").apply { mkdirs() }
        val tileFile = File(levelDir, "${col}_${row}.jpg")
        FileOutputStream(tileFile).use { fos ->
            tileBitmap.compress(Bitmap.CompressFormat.JPEG, jpegQuality, fos)
        }
    }

    /**
     * Generates a lower pyramid overview level directly from a downscaled preview bitmap so
     * zoom-out levels render instantaneously at 60fps.
     */
    fun writeOverviewFromPreview(previewBitmap: Bitmap) {
        var current = previewBitmap
        var level = ceil(ln(max(current.width, current.height).toDouble()) / ln(2.0)).toInt()
            .coerceAtMost(maxLevel - 1)

        while (level >= 8) {
            val levelDir = File(tilesRootDir, "$level").apply { mkdirs() }
            val cols = ceil(current.width.toDouble() / tileSize).toInt()
            val rows = ceil(current.height.toDouble() / tileSize).toInt()

            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    val x = c * tileSize
                    val y = r * tileSize
                    val w = min(tileSize, current.width - x)
                    val h = min(tileSize, current.height - y)
                    val tile = Bitmap.createBitmap(current, x, y, w, h)
                    FileOutputStream(File(levelDir, "${c}_${r}.jpg")).use { fos ->
                        tile.compress(Bitmap.CompressFormat.JPEG, 90, fos)
                    }
                    tile.recycle()
                }
            }

            if (current.width <= tileSize && current.height <= tileSize) break
            val nextW = max(1, current.width / 2)
            val nextH = max(1, current.height / 2)
            val scaled = Bitmap.createScaledBitmap(current, nextW, nextH, true)
            if (current !== previewBitmap) current.recycle()
            current = scaled
            level--
        }
        if (current !== previewBitmap) current.recycle()
    }
}
