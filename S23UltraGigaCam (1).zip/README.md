# S23 Ultra GigaCam (اپلیکیشن عکاسی فوق‌حرفه‌ای و گیگاپیکسلی سامسونگ S23 Ultra)

اپلیکیشن بومی اندروید (**Kotlin + Jetpack Compose + Camera2 API + C++17 NDK + ONNX Runtime NNAPI/Hexagon NPU**) طراحی‌شده اختصاصی برای **Samsung Galaxy S23 Ultra (Snapdragon 8 Gen 2, ISOCELL HP2 200MP + 10x Periscope)**.

---

## قابلیت‌های کلیدی

### ۱. ثبت تصاویر فوق‌مگاپیکسلی و گیگاپیکسلی واقعی (200 تا 5000 مگاپیکسل)
| حالت رزولوشن | ابعاد پیکسلی (4:3) | روش ثبت و پردازش | فرمت خروجی |
| :--- | :--- | :--- | :--- |
| **200 MP** | `16320 × 12240` | سنسور مستقیم ISOCELL HP2 (`SENSOR_PIXEL_MODE_MAXIMUM_RESOLUTION`) | JPEG Ultra / RAW DNG |
| **300 MP** | `20000 × 15000` | **MFSR** (ترکیب ۸ فریم زیرپیکسلی لرزش دست) + بازسازی AI | JPEG Ultra + BigTIFF + DZI |
| **500 MP** | `25820 × 19365` | ترکیب زیرپیکسلی MFSR / ماتریس ۲×۲ + بازسازی AI | JPEG Ultra + BigTIFF + DZI |
| **800 MP** | `32660 × 24495` | **ماتریس گیگاپیکسلی ۳×۳** هدایت‌شده با ژیروسکوپ + دوخت کاشی‌ای Hann + AI | 64-bit BigTIFF + DeepZoom + Preview |
| **1000 MP (1 GP)** | `36515 × 27386` | ماتریس ۴×۳ با پردازش Out-of-Core بدون پر کردن RAM + AI | 64-bit BigTIFF + DeepZoom + Preview |
| **2000 MP (2 GP)** | `51640 × 38730` | ماتریس ۵×۴ با لنز پریسکوپ ۱۰x + دوخت بدون درز + AI | 64-bit BigTIFF + DeepZoom + Preview |
| **5000 MP (5 GP)** | `81650 × 61238` | ماتریس ۸×۶ با لنز ۱۰x + پردازش نواربه‌نوار (Out-of-Core) + AI | **64-bit BigTIFF** + **DeepZoom (.dzi)** + Preview |

> **نکته فنی مهم:** استاندارد فایل JPEG حداکثر تا عرض `65,535` پیکسل و TIFF عادی تا ۴ گیگابایت را پشتیبانی می‌کند (در حالی که عکس ۵۰۰۰ مگاپیکسلی غیرفشرده حدود ۱۵ گیگابایت داده خام دارد!). به همین دلیل موتور `TiledBigTiffWriter` از **BigTIFF 64-bit (Version 43)** با نوشتن نواربه‌نوار روی حافظه UFS 4.0 استفاده می‌کند و همراه با آن یک **هرم کاشی DeepZoom (`.dzi`)** می‌سازد تا نمایشگر داخلی **GigaViewer** بدون کرش حافظه (OOM) تا بزرگ‌نمایی **250x** روی عکس زوم کند.

### ۲. موتور هوش مصنوعی دو‌سطحی (AI Ultra-Enhance)
- **لایه ۱ (شبکه عصبی روی Hexagon NPU / NNAPI):** پشتیبانی از مدل‌های `realesrgan_x2.onnx` یا `swinir_x2.onnx` به‌صورت کاشی‌ای با همپوشانی و ترکیب Hann-Window (بدون خط برش بین کاشی‌ها).
- **لایه ۲ (موتور بومی C++17 آماده اجرا بدون نیاز به دانلود مدل):**
  - حذف نویز لبه‌حفظ‌کن (Edge-Preserving Bilateral Denoise)
  - رفع تاری و شارپنس اپتیکال (PSF Deconvolution Sharpening)
  - گستره دینامیکی سینمایی (**ACES Filmic HDR Tone Mapping**)
  - تقویت میکرو-کنتراست بافت
- ۶ پروفایل آماده: طبیعی حرفه‌ای، حداکثر وضوح و شارپنس، نجومی و نور کم، بازسازی زوم تله‌فوتو ۱۰۰x، HDR سینمایی، و خاموش.

### ۳. امکانات عکاسی کامل و حداکثری (Pro Suite)
- کنترل دستی کامل Camera2: **ISO (50–3200)**، **سرعت شاتر (1/8000 تا 15+ ثانیه)**، **فوکوس دستی دیوپتری**، **تراز سفیدی کلوین (2300K–10000K)**، جبران نوردهی **EV**، قفل AE/AF و کنترل OIS.
- سوئیچ مستقیم بین هر ۴ لنز فیزیکی S23 Ultra: **0.6x (13mm)**، **1x (23mm 200MP)**، **3x (69mm)**، **10x (230mm Periscope)**.
- خروجی **12-bit RAW DNG** هم‌زمان با JPEG.
- حالت‌های تخصصی: **ULTRA MP**، **PRO**، **AI MAX**، **HDR+ (Exposure Bracketing & Mertens Fusion)**، **FOCUS STACK (جاروب فوکوس ماکرو/منظره)**، **ASTRO (نجومی)**.
- ابزارهای منظره‌یاب زنده: **هیستوگرام زنده**، امتیاز **Focus Peaking**، هشدار **Zebra Clipping**، **تراز افق سه‌بعدی (Gyro Leveler)**، شبکه‌های کادربندی (یک‌سوم و نسبت طلایی)، پایش دمای باتری و فضای خالی دیسک.

---

## راهنمای ساخت APK و نصب روی Galaxy S23 Ultra

1. پوشه `S23UltraGigaCam` را در **Android Studio (Ladybug 2024.2+)** باز کنید.
2. مطمئن شوید **Android SDK 35** و **NDK + CMake 3.22.1** در SDK Manager نصب هستند.
3. گوشی **Samsung Galaxy S23 Ultra** را با USB Debugging متصل کنید و روی **Run** بزنید (یا از مسیر `Build > Build Bundle(s) / APK(s) > Build APK(s)` فایل APK بسازید).
4. *(اختیاری برای فعال‌سازی لایه شبکه عصبی Real-ESRGAN روی NPU)*: یک مدل `realesrgan_x2.onnx` را در پوشه `app/src/main/assets/models/` قرار دهید یا بعد از نصب در مسیر `Android/data/com.s23ultra.gigacam/files/models/realesrgan_x2.onnx` روی گوشی کپی کنید.
